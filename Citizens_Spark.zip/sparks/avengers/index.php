<?php
  	include 'batman.php';
	include 'superman.php';
	include 'spiderman.php';
	include 'flash.php';
	include 'hulk.php';
	include 'captainamerica.php';
	include 'thor.php';
	include 'wonderwoman.php';
?>
