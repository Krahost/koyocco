<?php

$CONFIG_KILLBOT = [
    'active'        => true, // If 'true' will set blocker protection active, and 'false' will deactive protection
    'apikey'        => 'jyu1zRP0pBdxLih_NCY6vtAiY2VwfYnGyx3DMDCixXDpu',
    'bot_redirect'  => '404' // Bot will be redirect to this URL or you can change with 403, 404, suspend or cloudflare.
];