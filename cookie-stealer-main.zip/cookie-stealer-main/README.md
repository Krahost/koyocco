# Cookie-Stealer

1. Upload `cookiestealer.php` to your server
2. Edit `cookie.php` to change `$server_ip` value with your server's URL or IP with port
3. Go to http://IP:port/cookie.php
4. cat `log.txt` to see the collected cookies

### Host Code 

1. `php -S ip:port`

### Credits

This code is based on what can be seen here: [Write an XSS Cookie Stealer in JavaScript to Steal Passwords](https://null-byte.wonderhowto.com/how-to/write-xss-cookie-stealer-javascript-steal-passwords-0180833/)
