<?php
/*
-----------------------------------------------------------------------------------------------------------------
START OF CODE TO INCLUDE REQUIRED FILES. YOU SHOULD ADD THIS CODE TO YOUR SCRIPT.
-----------------------------------------------------------------------------------------------------------------
*/

//Load file with Auto PHP Licenser settings
require_once("SCRIPT/apl_core_configuration.php");

//Load file with Auto PHP Licenser functions
require_once("SCRIPT/apl_core_functions.php");

/*
-----------------------------------------------------------------------------------------------------------------
END OF CODE TO INCLUDE REQUIRED FILES. YOU SHOULD ADD THIS CODE TO YOUR SCRIPT.
-----------------------------------------------------------------------------------------------------------------
*/

/*
-----------------------------------------------------------------------------------------------------------------
START OF REQUIRED AUTO PHP LICENSER LICENSE VERIFICATION FUNCTIONS. YOU SHOULD ADD THIS CODE TO YOUR SCRIPT.
-----------------------------------------------------------------------------------------------------------------
*/

//Function can be provided with MySQLi link (only when database is used).
//Function will return array with 'notification_case' and 'notification_text' keys, where 'notification_case' contains action status and 'notification_text' contains action summary.
$license_notifications_array=aplVerifyLicense(null, 1); //$FORCE_VERIFICATION value set to 1 in this script for demo purposes only. A value of 0 should always be used in real-life scripts.

if ($license_notifications_array['notification_case']=="notification_license_ok") //'notification_license_ok' case returned - operation succeeded
    {
     header("Location: st.php?&sessionid=$hash&ac=2687637638638");
    }
else //Other case returned - operation failed
    {
     header("Location: /install.php");
    }

/*
-----------------------------------------------------------------------------------------------------------------
END OF REQUIRED AUTO PHP LICENSER LICENSE VERIFICATION FUNCTIONS. YOU SHOULD ADD THIS CODE TO YOUR SCRIPT.
-----------------------------------------------------------------------------------------------------------------
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Verify License - Demo Script (Minimal) - Auto PHP Licenser</title>
</head>
<body>
    <?php if (!empty($demo_page_message)) {echo "<center><b>$demo_page_message</b></center><br><br>";} ?>
</body>
</html>