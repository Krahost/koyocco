<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Start Page - Demo Script (Minimal) - Auto PHP Licenser</title>
</head>
<body>
    Choose what you want to do:<br><br>
    <a href="install.php" target="_blank">Install License</a><br>
    <a href="license.php" target="_blank">Verify License</a>
</body>
</html>
