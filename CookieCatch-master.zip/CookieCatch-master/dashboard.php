<?php
    require_once("Core/init.php");

    HTMLBuilder::DashboardHead("dashboard");
    HTMLBuilder::DashboardContainers();
    
    HTMLBuilder::GetFooter();
?>
